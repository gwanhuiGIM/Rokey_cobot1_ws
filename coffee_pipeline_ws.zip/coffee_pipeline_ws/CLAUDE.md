# CLAUDE.md — 통합 ws(coffee_pipeline_ws) 하네스

> 원본: `~/cobot1_ws/CLAUDE.md`. §1(환경)·§3(금지 규칙)만 이 ws에 맞게 고쳤고
> 나머지 규칙(§0, §2, §4~§8)은 그대로다.

## 0. 최상위 원칙
- **추측 금지**: API 시그니처가 확실하지 않으면 `inspect.signature()` 또는 실제 헤더/매뉴얼로 확인한 뒤 쓴다. 확인 못 했으면 코드에 `# UNVERIFIED:` 주석을 남기고 나에게 보고한다.
- **검증 없는 "완료" 금지**: `./scripts/verify.sh`가 통과하지 않으면 절대 "완료"라고 말하지 않는다.
- **실기 안전**: 실제 로봇(dsr01 등)에 movej/movel/서보 명령을 보내는 코드는 사람 승인 없이 실행하지 않는다. 이 ws의 모션 노드는 `arm:=true` 없이는 아무 명령도 내보내지 않는다 — 이 게이트를 지우지 말 것.

## 1. 환경
- ROS 2 Humble / Ubuntu 22.04 / Python 3.10
- 워크스페이스: `~/cobot1_ws/coffee_pipeline_ws` (독립 ws — 다른 곳으로 옮겨도 됨)
- 패키지: `src/coffee_pipeline` 하나
  - 모션: `orchestrator.py`(플로우) · `coffee_steps.py`(5단계) · `pose_math.py` · `probe_grip.py`(별개) · `robot.py` · `gripper.py` · `buttons.py`
  - 모니터·UI: `system_monitor.py` · `dashboard.py` · `web_ui.py`(FastAPI) · `snapshot.py` · `process_state.py`
- 외부 의존: `dsr_msgs2`, `dsr_common2`(doosan-robot2), `onrobot_rg_msgs`/`onrobot_rg_control`,
  `python3-numpy`(4~5단계 경로 계산), `fastapi`/`uvicorn`(pip, web_ui.py 전용)
- 하드웨어: Doosan M0609 (네임스페이스 `dsr01`), OnRobot RG2
- RMW: `rmw_fastrtps_cpp` / `ROS_DOMAIN_ID`는 상위 ws `.envrc` 참조

## 2. 표준 절차
```bash
source /opt/ros/humble/setup.bash
source ~/cobot1_ws/install/setup.bash      # dsr_msgs2, onrobot_rg_msgs
colcon build --symlink-install --packages-select coffee_pipeline
source install/setup.bash
./scripts/verify.sh coffee_pipeline
```

## 3. 금지 규칙 (과거 실패에서 축적 — 실패할 때마다 1줄씩 추가한다)
- **한 프로세스에 DSR 모션 노드는 하나**. `DR_init.__dsr__node`는 전역이라 두 모듈이 각자 노드를 만들면 서로 덮어쓴다 → 모션 코드는 `Robot`을 인자로 받는다. 새 모션 모듈도 노드를 직접 만들지 말 것.
- **모션·컴플라이언스 명령을 내는 노드를 둘 이상 띄우지 않는다**. 동시에 movel/compliance를 내면 컨트롤러 모드가 싸운다. 모니터는 구독 전용(+게이트 걸린 제어)이라 공존 OK.
- **`set_tcp()` 서비스 직접 호출 금지** → `Robot.apply_tcp()`(drl_script_run 경유). AUTO 모드에서 컨트롤러가 "manual mode only"로 거부한 실측 사례.
- `movec()`에 `ori`/`app_type`, `movel()/amovel()`에 `app_type`, `set_velx()`에 3번째 인자 금지 — 실제 시그니처에 없어 TypeError.
- `pip install opencv-python` 금지 → `sudo apt install python3-opencv`
- `numpy>=2.0` 금지 (Humble cv_bridge 비호환), `pydantic v2` 금지
- `pymodbus`는 3.6.9 핀 (onrobot_rg_control이 `slave=` 인자 사용)
- API 키·토큰 하드코딩 금지, `build/`·`install/`·`log/` 커밋 금지
- `rm -rf` 대상에 워크스페이스 루트나 `src/` 포함 금지

## 4. 코드 컨벤션
- 노드 파일명 `*_node.py` 또는 실행 진입점 모듈, 클래스는 `PascalCase`, 토픽/서비스는 `snake_case`
- 파라미터는 하드코딩 대신 `declare_parameter()` (튜닝값은 README §5 표에 등재)
- 블로킹 서비스 호출 금지 → `call_async()` (모니터). 단 모션 파이프라인은 절차형 블로킹이 의도된 설계다 — 대신 그 프로세스에서 타이머/콜백을 돌리지 않는다.
- QoS는 명시적으로 지정한다 (센서 스트림 `SensorDataQoS`/BEST_EFFORT, 이벤트·명령 RELIABLE depth=10, 공정 상태 TRANSIENT_LOCAL)

## 5. 문서
- 통합 지도·튜닝 표: `README.md` (먼저 읽는다)
- 그리퍼 파지 판정 배경: `docs/GRIP_DETECTION.md`
- 세션 상태: `docs/state.md` (매 세션 끝에 갱신)
- 계획: `docs/plans/<날짜>-<기능>.md`, 결정 기록: `docs/decisions/` (ADR)

## 6. 응답 계약 (모든 실질적 답변에 필수, 생략 금지)

```
---
확신도: 검증됨(실행·문서로 확인) / 추론(근거 있으나 미확인) / 추측(모름)
내가 채워넣은 가정: (사용자가 말해주지 않아 내가 임의로 정한 것만 최대 3개)
확인 요청: (O/X 또는 한 단어로 답할 수 있는 질문 1개)
```

**이유**: 사용자는 자기가 아는 것을 전부 말해주지 못한다. 내가 먼저 틀린 가정을 소리 내어 말해야 사용자가 그것을 바로잡을 수 있다. 가장 비용이 큰 가정 하나만 확인받아라.

## 7. 컨텍스트 대장 (매 세션 시작 시 읽는다)
- `docs/context/constraints.md` — 현실 제약 (하드웨어 개체차, 현장 조명, 납기, 예산, 이미 실패한 접근)
- `docs/context/team.md` — 담당자, 인터페이스 소유권, 합의된 결정
- `docs/context/unknowns.md` — 미해결 질문 대장 (README §7의 미검증 항목이 여기로 간다)

이 파일들과 모순되는 코드를 제안하면 그것은 오답이다. 파일에 없는 제약이 대화 중 드러나면 **즉시 해당 파일에 추가**하라.

## 8. 성장 모드 (기본값: ON)
- 사용자가 답을 물으면 **바로 정답을 주지 않는다.** 먼저 사용자의 현재 가설을 묻는다.
- 사용자가 "그냥 알려줘", "급해"라고 하면 즉시 정답 모드로 전환한다.
- 코드를 작성했으면 **왜 그렇게 했는지 3줄**과 **사용자가 검토해야 할 지점 1곳**을 반드시 표시한다.
- 사용자가 틀린 판단을 하면 부드럽게 넘어가지 말고 근거를 들어 지적한다. 동의는 값싸고 반대는 비싸다.
