# coffee_pipeline_ws — 커피 공정 + 컵 파지 + 시스템 모니터 + 웹UI 통합 ws

M0609 + OnRobot RG2 핸드드립 시스템의 **여러 모듈을 한 프로세스/한 상태머신으로
합쳐 놓은 작업용 워크스페이스**. 플로우·예외처리·모니터·웹UI 연결은 여기서 이어붙인다.

원본 → 여기

| 원본 | 여기 | 상태 |
|---|---|---|
| `src/coffee_system/coffee_system/m0609_coffee_system_v2.py` (1~3단계) | `coffee_steps.py` + `buttons.py` + `robot.py` | 분해·재조립 |
| `src/rokey/rokey/coffee_system.py` (4~5단계, 2026-07-28 반영) | `coffee_steps.py`의 `hand_drip()`/`final_pour()` + `pose_math.py` | 위 파일에 이어붙임 |
| `src/coffee_system/GRIP_DETECTION_README.md` | `docs/GRIP_DETECTION.md` + `gripper.py` | 문서의 TODO를 코드로 반영 |
| `src/cup_detect/cup_detect/probe_grip_v2.py` | `probe_grip.py` | 노드/그리퍼/TCP 경로만 교체 (공정과는 별개 모듈) |
| `src/monitor_pjt/*` | `system_monitor.py` `dashboard.py` `snapshot.py` `process_state.py` | 거의 그대로, STEPS만 통합 |
| `src/rokey/rokey/web_ui.py` (2026-07-28 반영) | `web_ui.py` | HTML/JS 그대로, 상태 소스만 `/coffee_process/state`로 교체 |
| (없음) | `orchestrator.py` | **플로우 뼈대 — 당신이 계속 채울 파일** |

---

## 1. 아키텍처 — 프로세스 4개

```
┌───────────────────────────────┐  /coffee_process/state   ┌────────────────────┐
│ orchestrator (모션, 유일한 DSR) │ ───────────┬───────────▶ │  system_monitor     │
│  Robot ─ Gripper ─ CoffeeSteps │  (TRANSIENT_LOCAL)       │  로봇 상태 폴링·안전  │
│  (probe_grip은 별도 단독 실행)  │             │            │  판정·스텝 감시      │
└───────────────────────────────┘             │            └─────┬────────┬─────┘
        │ DSR 서비스/토픽 (모션)                │      ~/status ~/log     ▲ ~/cmd
        ▼                                      ▼                ▼        │
   M0609 컨트롤러 · RG2(onrobot_rg_control)   web_ui(FastAPI)◀──┴───► dashboard(Qt)
                                             고객화면 + 관리자화면
```

- **모션 명령을 내는 프로세스는 orchestrator 하나뿐**이다. `DSR_ROBOT2`는 전역
  노드(`DR_init.__dsr__node`)를 공유하므로 두 모듈이 각자 노드를 만들면 서로
  덮어쓴다 → `Robot` 객체 하나를 만들어 `CoffeeSteps`에 넘긴다.
  (전역 대입은 반드시 모듈 레벨 `robot.bind_dsr_node()`로 — 클래스 안에서 쓰면
  이름 맹글링으로 `_Robot__dsr__node`에 들어가 노드가 None으로 남는다.)
- 모니터·웹UI는 **구독 전용 + 게이트 걸린 제어**라 공존해도 안전하다. 단
  `control_enabled:=true`로 켜면 jog/이동/그리퍼 명령을 낼 수 있으니 실기 중에는
  끄고 쓰는 게 기본.
- `dashboard`·`web_ui`는 `dsr_msgs2`를 import하지 않는다 → 로봇 SDK 없는 PC에서도
  띄워 원격 모니터링 가능. 대시보드(Qt, 로컬)와 웹UI(브라우저, 원격 가능)는
  **같은 system_monitor 토픽에 붙는 두 개의 독립된 클라이언트**다 — 하나가
  죽어도 다른 쪽은 멀쩡하고, 웹UI 관리자 화면 여러 개를 동시에 띄워도 된다.
- 웹UI는 두 화면을 겸한다: **고객 화면**(`/`, 상태 표시 전용, 공정 진행을
  보여줌 — `/coffee_process/state` 구독)과 **관리자 화면**(`/admin`, 로컬
  접속만 허용 — system_monitor의 `~/status`/`~/log`/`~/cmd` 그대로 사용,
  기능은 대시보드와 거의 겹친다. 원격 접속·태블릿용 대체 UI로 보면 된다).

## 2. 빌드 · 실행

```bash
source /opt/ros/humble/setup.bash
source ~/cobot1_ws/install/setup.bash          # dsr_msgs2, onrobot_rg_msgs 제공
cd ~/cobot1_ws/coffee_pipeline_ws
colcon build --symlink-install && source install/setup.bash
pip install fastapi uvicorn                     # web_ui.py 전용 (rosdep 키 없음)
./scripts/verify.sh coffee_pipeline             # 빌드+테스트 게이트
```

> 이 ws가 `cobot1_ws` 밑에 있는 동안 상위 ws에서 `colcon build`를 하면 여기까지
> 같이 빌드된다. 밖으로 옮기거나 상위에서는 `--packages-select`를 쓸 것.

실행 (드라이버가 먼저 떠 있어야 한다):

```bash
# 0) 로봇 + 그리퍼 드라이버
ros2 launch dsr_bringup2 dsr_bringup2_rviz.launch.py mode:=real host:=192.168.1.100 model:=m0609 name:=dsr01
ros2 run onrobot_rg_control OnRobotRGSimpleController   # 파지 판정에 필수

# 1) 모니터 (먼저 띄워 두면 공정 상태가 처음부터 보인다)
ros2 launch coffee_pipeline monitor.launch.py

# 1-1) 웹UI (선택) — 고객 화면 http://<로봇PC>:8000/, 관리자 http://127.0.0.1:8000/admin
ros2 run coffee_pipeline web_ui

# 2) 공정 — 사람 감독 하에, 저속으로
ros2 run coffee_pipeline orchestrator --ros-args -p arm:=true

# 컵 파지만 따로 튜닝할 때 (컴플라이언스 접촉 탐지 파라미터 잡기)
ros2 run coffee_pipeline probe_grip --ros-args -p arm:=true -p detect_enabled:=false
```

**`arm:=true`가 없으면 모션 명령을 하나도 내보내지 않는다.** 드라이런/파라미터
확인은 항상 이 상태로 먼저.

## 3. 공정 플로우 (= `process_state.STEPS`, 단일 진실 소스)

공정은 **5단계 전체가 확정**됐다 (2026-07-28, `src/rokey/rokey/coffee_system.py`
최신본 반영). 컵 접촉 탐지(`probe_grip`)는 이 공정과 무관한 별개 모듈이다 —
"6번째 단계 자리"가 아니라 그냥 독립 노드다(예전에 그렇게 추측했던 기록은
`docs/plans/2026-07-27-full-6-stage-flow.md`에 정정해뒀다).

```
INIT → HOME
  1단계 원두      SELECT_BEAN → BEAN_DROP        (스푼 파지 → 그라인더 투입)
  2단계 그라인딩   SELECT_GRIND → GRINDING        (손잡이 파지 → 회전 분쇄)
  3단계 운반      BOTTLE_PICK → BOTTLE_MOVE → WAIT_TAP → BOTTLE_RETURN
                                                 (병 파지 → 이송/붓기 → 힘제어 외력 감지)
  4단계 핸드드립   HAND_DRIP                       (주전자 파지 → 위치보상 내향 스파이럴 붓기 → 반환)
  5단계 최종붓기   FINAL_POUR                      (필터홀더+물컵 배치 → 위치보상 붓기)
→ DONE
```

`FINAL_POUR`는 시작 자세로 복귀하지 않는다 — 붓는 자세가 사이클의 마지막
자세다(원본과 동일 동작). 더 붙일 단계가 생기면: `process_state.STEPS`의
`DONE` 앞에 스텝 줄을 추가하고, `CoffeeSteps`에 메서드를 추가한 뒤
`orchestrator.run_cycle`에서 `run_stage()`로 호출. `test_flow_contract.FLOW`와
`web_ui.STEP_TO_SCREEN`도 같이 고친다(안 고치면 테스트가 깨진다 — 의도된 게이트).

- 순서를 바꾸려면 `process_state.STEPS` 리스트만 고치면 된다. 진행률·대시보드
  칩·모니터의 "스텝 건너뜀 경고"·웹UI 화면 전환이 전부 따라온다.
- `SELECT_*`는 DI 13~16 물리 버튼 대기(블로킹), `WAIT_TAP`은 사람이 병을 칠
  때까지 외력 대기(블로킹).
- 4~5단계는 `movesx()`로 위치보상 경로를 직접 만들어 던진다(회전행렬·오일러
  변환은 `pose_math.py`). 자세한 원리는 `coffee_steps.py`의 `hand_drip()`/
  `final_pour()` docstring 참고 — 요지: Joint6을 일정량 돌렸을 때 생기는
  TCP 끝단(주둥이) 위치 변위를 fkin으로 미리 계산해, 나선/기울임 내내 그
  변위를 역보상하는 경로를 만든다. 그래서 실제로는 주둥이가 허공에 거의
  고정된 채로 손목만 기울며 붓는 것처럼 보인다.

### 3-1. 물리 버튼 없이 누르기 (가상 버튼)

컨트롤박스에 손이 안 닿거나 배선 전에 플로우만 돌려볼 때, `SELECT_*` 대기를
토픽으로도 푼다. 물리 버튼과 완전히 같은 자리에 선다.

```bash
ros2 topic pub --once /coffee_process/button_press std_msgs/msg/UInt8 "{data: 13}"
```

대시보드 "5. IO / 그리퍼" 패널의 **누르기** 버튼이 이걸 그대로 쏜다. 물리 버튼도
게이트가 없으므로 이 버튼도 "제어 활성화"와 무관하게 항상 눌린다 — 로봇을 직접
움직이는 명령이 아니라 orchestrator가 기다리는 선택지를 답하는 것이기 때문.

값은 13~16만 받는다(그 외는 WARN 후 무시). 래치는 1개라 연달아 보내면 마지막
것만 남고, 대기 중이 아닐 때 보낸 것은 다음 `SELECT_*`에서 소비된다.

### 3-2. 그리퍼 개폐 테스트 (대시보드)

같은 패널의 **닫기 5mm / 열기 35·70·104mm** 버튼. `system_monitor`가
`io/set_ctrl_box_digital_output`으로 DO 1/2 조합(= 컴퓨트박스 프리셋)을 쓴다 —
조합표는 `gripper.py`가 단일 진실 소스다. 모션이 아니라 접점 출력이지만 공정
중에 열면 물건을 떨어뜨리므로 **"제어 활성화" 게이트 뒤**에 있다.

## 4. 통합하면서 내린 결정 (뒤집고 싶으면 여기부터)

| # | 결정 | 근거 | 뒤집는 법 |
|---|---|---|---|
| 1 | 컵 파지(probe_grip)를 공정에서 **분리** (2026-07-27) | 공정을 원두·그라인딩·운반 3단계로 고정. 컵 탐지는 단독 노드로만 실행 | `STEPS`에 CUP_* 3개 추가 + probe_grip의 `say()`를 `report.set`으로 되돌리고 `run_cycle`에서 호출 |
| 2 | TCP 전환은 `Robot.apply_tcp()`(DRL 경유) 하나로 통일 | 커피 노드 실측: `set_tcp` 서비스는 AUTO 모드에서 100% 거부. probe 원본은 "이미 그 TCP였다"라 안 밟았을 뿐으로 보임 | probe에서만 서비스 호출로 되돌리기 (권장 안 함) |
| 3 | 그리퍼 명령 채널을 파라미터로 (`digital_output` 기본) | 커피=DO 접점, probe=`/onrobot/sendCommand`. **한 실행에서 섞지 말 것** | `-p gripper_channel:=service` |
| 4 | 파지 판정을 커피 쪽 `grip_close` 지점에도 넣고 실패 시 `GripFailed` | GRIP_DETECTION §4: 놓친 채 이동하면 낙하 | `-p verify_grip:=false` (판정 없이 진행) |
| 5 | 웹UI 상태를 `/coffee_process/state` 하나로 일원화 (2026-07-27 결정, 2026-07-28 웹UI 부활 시에도 유지) | 상태 채널 2개는 곧 서로 어긋난다. 웹UI 고객 화면은 이 채널을 번역해서 쓴다(`web_ui.translate_process_state`) | `web_ui.py`가 다시 독자 채널을 구독하게 되돌리기 (권장 안 함) |
| 6 | `transfer_grounds()`(구 `dripper_in`) 안의 외력 대기를 그대로 유지 | 사람이 병을 치는 게 공정의 일부 | `CoffeeSteps.wait_for_external_force` 호출부 |
| 7 | 4~5단계(`hand_drip`/`final_pour`) 추가, 6단계였던 "컵 서빙" 추측은 폐기 (2026-07-28) | `coffee_system.py` 최신본에 실제 좌표·로직이 있었다. 서빙 단계는 없다 | `docs/plans/2026-07-27-full-6-stage-flow.md`에 원래 추측 기록 |
| 8 | `movesx()` 호출은 `time=` kwargs 우선, 실패 시 `vel`+`acc`+`time=` 2단계 폴백만 유지 | 이 환경에서 시그니처를 `inspect.signature()`로 실측 확인함 — 위치인자 폴백(원본 4단계)은 구버전 대비였는데 불필요해졌다 | `CoffeeSteps._call_movesx()` |
| 9 | web_ui 관리자 화면의 `move_task` 회전(A/B/C)에서 `tcp_offset`(피벗 오프셋) 보상은 **구현 안 함** | 검증 안 된 수학으로 실기 회전을 왜곡시키는 위험을 피함. 단순 TOOL 프레임 상대회전만 낸다 | `system_monitor.move_task()` — pose_math로 피벗 보상 공식을 검증한 뒤 추가 |

## 5. 튜닝 필요 요소 (실기에서 다시 맞춰야 하는 값)

**검증** 열: `실측`=실기 로그로 확인된 값 / `교시`=티치펜던트 값 그대로 /
`추정`=근거 있는 기본값, 현장 재확인 필요.

> 한눈에 보려면 [`docs/tuning_status.html`](docs/tuning_status.html) — 영역별 확신도 분포,
> 공정 플로우, 실기 전 확인 7건, 36개 항목 표. 브라우저로 그냥 열면 된다(외부 의존 없음).
> 이 표를 고치면 그 파일의 `ROWS` 배열도 같이 고칠 것.

### 5-1. 좌표 · 자세 — 작업물이 조금만 움직여도 전부 틀린다
| 값 | 위치 | 기본 | 검증 | 언제 다시 잡나 |
|---|---|---|---|---|
| `SPOON_J/L`, `GRINDER_J/L`, `HANDLE_J/L`, `BOTTLE_*`, `DRIP_J/L`, `HOME_J` | `coffee_steps.py` 상단 | System.drvar 원본 | 교시 | 그라인더·드리퍼·병·스푼 거치대를 옮겼을 때 → 티치펜던트 재교시 |
| `GRIND_ARC_VIA/END`, `GRIND_USER_COORD=101` | `coffee_steps.py` | 원본 | 교시 | 사용자 좌표계 101이 컨트롤러에 없으면 movec가 실패 |
| `detection_ready_xyz` `[300,-600,110]` | probe_grip 파라미터(단독) | probe 기본값 | 추정 | **컵 놓는 위치가 바뀔 때마다.** Z=110은 컵 몸통 중앙 높이 |
| `grasp_orientation` `[-90,90,90]` | probe_grip 파라미터(단독) | probe 기본값 | 추정 | 측면 파지 손목 자세. 그리퍼가 컵에 비스듬히 닿으면 여기부터 |
| `place_pose` / `place_via_pose` | probe_grip 파라미터(단독) | probe 기본값 | 추정 | 컵을 내려놓을 자리. 공정 재통합 시 재확정 |

### 5-2. 접촉 탐지 (probe_grip) — 가장 예민한 부분
| 값 | 기본 | 검증 | 의미 · 증상 |
|---|---|---|---|
| `contact_force_n` | 8.5 N | 추정 | 낮추면 오탐(공기 중 정지), 높이면 컵을 밀고 지나감. 허용 범위 [3,30] |
| `contact_force_dir` | -1.0 | 추론 | +X 접근 시 반력은 -X. 부호가 반대로 나오면 +1.0 |
| `stiffness` | `[200,3000,3000,200,200,200]` | 추정 | X만 약하게 = 부드러운 접촉. 컵이 밀리면 X를 더 낮춤 |
| `settle_time_s` | 0.6 s | 추정 | 컴플라이언스 진입 직후 과도응답을 접촉으로 오인하지 않게 하는 무시 구간 |
| `probe_x_depth_mm` | 200 mm | 추정 | 이 안에 접촉 없으면 "물체 없음". 컵 위치 불확실성보다 크게 |
| `object_radius_mm` | 45 mm | 추정 | 접촉면 → 파지중심 X 후퇴량. **종이컵 반경으로 재측정** |
| `grasp_y_standoff_mm` / `grasp_y_offset_mm` | 100 / 15 mm | 추정 | +Y 안전 대기 → -Y 진입 최종 위치. 컵을 쓰러뜨리면 offset부터 |
| `grasp_z_above_center_mm` | 0 mm | 추정 | 파지 높이 보정 |
| `speed_mm_s` / `acc_mm_s2` | 40 / 40 | 추정 | 탐지 중 속도. 빠르면 정지 거리만큼 더 눌린다 |
| Tool payload 프리셋 | `Tool Weight_gripper` | 교시 | **비어 있으면 외력 추정이 편향돼 접촉 탐지가 통째로 부정확** (경고 로그 확인) |

### 5-3. 파지 판정 (gripper) — `docs/GRIP_DETECTION.md`
| 값 | 기본 | 검증 | 비고 |
|---|---|---|---|
| `POS_CLOSED_EMPTY` | 0.7587 rad | 실측(40N) | 빈손 닫힘 position. **힘 프리셋을 바꾸면 재측정**: 빈손으로 닫고 `ros2 topic echo /onrobot_joint_states` |
| `POS_MARGIN` | 0.02 rad | 실측 | 빈손-물체 갭이 ≈0.045 rad라 절반 수준 |
| `GRIP_SETTLE_S` | 1.5 s | 추정 | 닫기 명령 후 기구 정착 대기. 짧으면 판정이 흔들린다 |
| `VERIFY_TIMEOUT_S` | 3.0 s | 추정 | grip 비트를 못 받으면 effort→position 순으로 폴백 |
| DO 프리셋 폭/힘 (5/35/70/104 mm, 40 N) | 컴퓨트박스 웹UI | 실측 | **코드가 아니라 컴퓨트박스에 저장된 값이다.** 종이컵엔 40N이 과함 → RG2 최소치(≈3N) 프리셋 권장 |
| 스푼·손잡이 파지 판정 | 켜짐 | 미검증 | 얇은 스푼/손잡이에서 grip 비트가 어떻게 나오는지 미확인. 오탐 나면 `CoffeeSteps._grip(..., verify=False)` |

### 5-4. 커피 공정
| 값 | 기본 | 검증 | 비고 |
|---|---|---|---|
| `FORCE_TRIGGER_N` | 4.0 N | 추정 | 병 두드림 판정. 원본 주석은 10 N인데 코드는 4.0 — 실기에서 조정된 흔적 |
| `FORCE_SETTLE_SEC` / `FORCE_BASELINE_SAMPLES` / `FORCE_CONFIRM_SAMPLES` | 0.6 s / 20 / 2 | 추정 | move_periodic 잔류 진동 대비. 오탐 잦으면 confirm 늘리기 |
| `GRIND_BY_BUTTON` turns (3/5/7/10) · `DEGREES_PER_GRINDER_TURN=360` | 원본 | 추정 | 실제 분쇄 굵기와의 대응은 관능 확인 필요 |
| `GRIND_STIFFNESS` | `[1500,1500,2500,150,150,200]` | 원본 | 손잡이가 튀면 낮춘다 |
| `GRIND_PROGRESS_POLL_SEC` | 0.10 s | 추정 | 분쇄 중 회전량 측정 주기. 낮추면 `get_current_posx`/`check_motion` 서비스 호출이 모션에 부하가 될 수 있다 |
| `GRIND_START_TIMEOUT_SEC` | 2.0 s | 추정 | `amovec` 후 이 안에 BUSY를 못 보면 측정을 접고 `mwait(0)`로만 대기 |
| `DRIP_PERIODIC_*` (amp 2.0°, period 0.3, repeat 5) | 원본 | 추정 | 추출 흔들기 강도/횟수 |
| `DRIP_TCP_NAME = "joint4"` | 원본 | 교시 | 컨트롤러에 이 TCP가 없으면 전환 실패 → 기본 TCP로 흔든다(경고 로그) |
| `VELJ/ACCJ/VELX/ACCX` | 20/35/80·25/300·100 | 원본 | 실기 첫 실행은 더 낮춰서 |
| 버튼 `DEBOUNCE_SEC` 0.05 / `BASELINE_STABLE_SEC` 0.2 | | 추정 | 채터링 있으면 늘린다 |

### 5-4b. 핸드드립 (4단계, `hand_drip()`)
| 값 | 기본 | 검증 | 비고 |
|---|---|---|---|
| `POT_GRIP_L/J`, `POUR_START_J`, `POT_PICKUP_APPROACH_REL/LIFT_REL` | coffee_system.py 원본 | 교시 | 주전자 거치대를 옮기면 재교시 |
| `SPOUT_TCP_NAME="pot"` | 원본 | 교시 | 컨트롤러에 이 TCP 프리셋이 없으면 `apply_tcp` 실패 -> RuntimeError |
| `SPIRAL_RADIUS_MM` / `SPIRAL_REVOLUTIONS` / `SPIRAL_DURATION_SEC` | 44 mm / 5 / 15 s | 추정 | 드리퍼 안지름보다 반경이 크면 물이 밖으로 튄다 |
| `SPIRAL_J6_DELTA_DEG` | -60° | 추정 | 주전자를 기울이는 "가상 회전량". 물이 안 나오면(너무 세우면) 키우고, 너무 쏟아지면 줄인다 |
| `SPIRAL_CENTER_OFFSET_SIGN_X` / `SPIRAL_ROTATION_SIGN` | -1.0 / 1.0 | 추정 | 나선이 반대 방향/반대편에서 시작하면 부호부터 뒤집어본다 |
| `MOVESX_MAX_LINEAR_STEP_MM` / `MOVESX_MAX_ANGULAR_STEP_DEG` | 15 mm / 5° | 추정 | 경로 검증 한계. 이 값을 넘으면 경로 생성 단계에서 바로 멈춘다(모션 나가기 전) |
| `CENTER_PIVOT_RETURN_DURATION_SEC` | 3.0 s | 추정 | 스파이럴 후 주전자를 세우는 시간. 너무 빠르면 흔들림 |

### 5-4c. 최종 붓기 (5단계, `final_pour()`)
| 값 | 기본 | 검증 | 비고 |
|---|---|---|---|
| `FILTER_HOLDER_*`, `MUG_*`, `FINAL_POUR_L/J2`, `FINAL_POUR_APPROACH_J` | coffee_system.py 원본 | 교시 | 필터홀더/물컵 거치대를 옮기면 재교시 |
| `FINAL_POUR_TCP_NAME="mug"` | 원본 | 교시 | 없으면 `apply_tcp` 실패 -> RuntimeError (hand_drip과 달리 실패 시 계속 진행하지 않음) |
| `FINAL_POUR_SPOUT_OFFSET_TOOL_MM` | `[1,1,1]` mm | **미검증** | mug TCP 원점에서 실제 물 붓는 지점(주둥이)까지의 툴 프레임 오프셋. `[1,1,1]`은 원본 값 그대로인데 원 단위로 봐도 너무 작아 보임(mug 크기 대비) — 실기에서 `spout_error_mm` 로그로 재추정 필요 |
| `FINAL_POUR_J6_DELTA_DEG` | 45° | 추정 | 컵을 기울이는 가상 회전량 |
| `FINAL_POUR_DURATION_SEC` | 8.0 s | 추정 | |
| `FINAL_POUR_MAX_LINEAR_STEP_MM/ANGULAR_STEP_DEG` | 5 mm / 3° | 추정 | hand_drip보다 빡빡하다(짧은 경로라 더 촘촘해야 함) |
| `FINAL_POUR_SPOUT_ERROR_WARN_MM` | 3.0 mm | 추정 | 붓기 후 실측 주둥이 오차가 이보다 크면 WARN 로그 — TCP/오프셋 재확인 신호 |
| `FINAL_DRIP_VELJ/ACCJ/VELX/ACCX` | 60/100/250·80.625/1000·322.5 | 원본 | **이 단계부터는 복원하지 않는다**(사이클이 여기서 끝나므로). 재시도 시 `run_stage`가 `apply_motion_defaults()`로 되돌린 뒤 `home()` 한다 |

### 5-5. 모니터
| 값 | 기본 | 비고 |
|---|---|---|
| `STALE_SEC` / `DISCONNECTED_SEC` | 0.5 / 2.0 s | 링크 등급 경계 |
| `PUBLISH_HZ` / `POLL_HZ` | 10 / 5 Hz | 서비스 폴링이 모션 중 부하가 되면 낮춘다 |
| `MAX_JOG_SPEED_PCT` | 20 % | GUI jog 하드 리밋 |
| `control_enabled` | false | true로 켜도 GUI 체크박스를 또 눌러야 함. 실기 자동운전 중에는 false 권장 |
| `evaluate_safety()` 충돌 판정 | SAFE_STOP + SAFETY 그룹 에러 | 충돌 전용 토픽이 없어 **추정**. 실기에서 실제 코드 확인해 좁힐 것 |

### 5-6. 웹UI (`web_ui.py`)
| 값 | 기본 | 검증 | 비고 |
|---|---|---|---|
| `STEP_TO_SCREEN` | 코드 참고 | 추정 | STEPS에 새 스텝 추가 시 여기도 같이 고쳐야 화면이 안 밀린다 (`test_web_ui_translate.py`가 STEPS와의 1:1 대응을 검증) |
| `MAX_MOVE_TASK_DISTANCE_MM` / `ANGLE_DEG` | 50 mm / 30° | 추정 | 관리자 화면 1회성 이동 버튼의 하드 캡. 실기 첫 사용은 더 낮춰서 |
| `MAX_MOVE_TASK_LINEAR_VEL_MM_S` / `ANGULAR_VEL_DEG_S` | 100 / 30 | 추정 | 위와 동일 목적 |
| `MAX_JOINT6_DELTA_DEG` | 30° | 추정 | J6 단독 회전 버튼 캡 |
| move_task의 `tcp_offset`(피벗 오프셋) | 미구현 | — | 결정 9 참고. 값을 받아 로그도 안 남기고 버린다 — 버튼을 눌러도 요청한 피벗 회전은 안 나가고 TOOL 프레임 단순 회전만 나간다 |
| 관리자 화면 인증 | IP만 검사(127.0.0.1/::1) | 원본 | 로봇 PC 로컬 접속만 허용. 원격에서 관리자 화면을 쓰려면 SSH 터널 등 별도 방법 필요(코드 수정 없이) |

> [`docs/tuning_status.html`](docs/tuning_status.html)은 **2026-07-27 시점(1~3단계, 36개 항목) 스냅샷이라
> 지금은 낡았다** — 4~5단계·웹UI 항목이 안 실려 있다. 갱신하려면 그 파일의 `ROWS` 배열에
> 위 5-4b/5-4c/5-6 표 내용을 추가할 것 (자동 생성 아님, 수동 유지).

## 6. 당신이 채워야 할 곳 (orchestrator.py의 TODO)

1. **파지/탐지 실패 정책** — 지금은 `GripFailed`/"컵 없음" 모두 즉시 정지 후 사람.
   재시도(열고 재접근)를 넣을지, 몇 번까지 할지.
2. **컵 파지의 공정 내 위치** — 결정 1의 가정 확정.
3. **사이클 반복 · 외부 중단 요청** — 지금은 1 사이클 후 종료. 반복하려면
   `run_cycle`을 while로 감고, 중단은 토픽/서비스로 받아 `robot.stop()`.
4. **예외 후 복구** — 지금은 정지만 하고 그 자리에 멈춘다(장애물 상황을 모르는
   채 움직이는 게 더 위험하다는 판단). 자동 홈 복귀를 원하면 `_safe_stop` 뒤에.
5. **모니터 → 공정 제어** — 대시보드에서 "일시정지/재개"를 누르게 하려면
   `system_monitor`의 `~/cmd`에 커맨드를 추가하고 orchestrator가 그것을
   구독해야 한다(지금은 모니터가 로봇 컨트롤러만 직접 건드린다).

## 7. 아직 검증되지 않은 것 (실기 전에 확인)

- [ ] 통합본으로 실기 1 사이클 완주 — **아직 로봇에서 돌려본 적 없다.** 빌드와
      로봇 없는 테스트(24개)만 통과한 상태. 특히 4~5단계는 이번에 처음
      포팅된 movesx 기반 위치보상 경로라 우선순위가 가장 높다.
- [ ] **분쇄 원호 진행 방향 판정** — `_grind_arc`는 "현재점 → `GRIND_ARC_VIA`"
      방향으로 회전 방향을 정한다. `GRIND_READY_J` 직후 TCP가 좌표계 101에서
      경유점과 거의 정반대(Δ≈±180°)에 있으면 부호가 뒤집혀 진행률이 0%에
      붙박인다(모션 자체는 정상). 실기 1회차에 로그로 확인할 것.
- [ ] `get_current_posx(ref=101)`를 10 Hz로 폴링하는 것이 컴플라이언스 원호
      모션에 부하가 되는지 (서비스 호출이 `spin_until_future_complete` 블로킹)
- [ ] **`movesx()` 실제 통과 조합** — 시그니처는 `inspect.signature()`로
      실측했지만(kwargs: pos_list/vel/acc/time/ref/mod/vel_opt), 컨트롤러가
      `time=`만 줬을 때 실제로 받아주는지 vel/acc를 꼭 같이 줘야 하는지는
      실기에서만 확인된다. `_call_movesx()`가 `time=`만 시도 -> TypeError 시
      vel/acc+time= 로 재시도하는데, 둘 다 컨트롤러가 다른 이유로(값 범위 등)
      거부하면 폴백이 못 잡는다 — 실기 1회차 로그 확인 필수.
- [ ] `FINAL_POUR_SPOUT_OFFSET_TOOL_MM = [1,1,1]` mm — mug TCP 원점에서 실제
      물 붓는 지점까지 오프셋인데 원본 값 그대로다. 물컵 크기 대비 1mm는
      비현실적으로 작아 보인다(§5-4c). 실기 붓기 후 `spout_error_mm` 로그로
      역산해 재설정할 것 — 지금 값으로는 "주둥이 고정"이 실제로는 안 될 수 있다.
- [ ] `robot.py`의 `TOOL_NAME = "Tool Weight123"`이 `coffee_system.py` 원본의
      `"Tool Weight_gripper"`와 다르다 — 실측 후 의도적으로 바뀐 값으로
      보여 이번 통합에서 되돌리지 않았다. 어느 쪽이 맞는지 확인 필요.
- [ ] `probe_grip`이 커피 시퀀스 뒤에 이어질 때의 시작 자세(`approach_joint`)
      안전성 — 분쇄 종료 자세에서 바로 이 관절자세로 가도 되는지 (여전히
      probe_grip은 별개 모듈이라 이 질문은 "붙여 쓸 계획이 생기면"의 얘기다)
- [ ] 스푼/손잡이/주전자/필터홀더/물컵에 대한 grip 비트 신뢰도 (5-3 마지막 줄) —
      4~5단계에서 새로 파지하는 물체 3종(주전자/필터홀더/물컵)도 포함
- [ ] 컵 파지 후 `place_pose`가 드리퍼와 간섭하지 않는지
- [ ] `onrobot_rg_control`이 DO 명령과 동시에 떠 있을 때 Modbus 읽기 간섭 없는지
- [ ] `FINAL_POUR` 실패 후 재시도(`run_stage`)가 `home()`부터 1~3단계를 다시
      밟는 게 맞는지 — 4~5단계가 이미 절반 끝난 상태(주전자/필터홀더 위치 등)에서
      1단계부터 다시 돌면 현실과 안 맞을 수 있다. §6 TODO 4와 연결된 문제.

## 8. 이 ws에 넣지 않은 것

- `coffee_system/web_ui_v2.py`, `check_weight.py`, `m0609_coffee_system_v1.py`,
  `coffee_system_v0.py`(현재본과 동일 백업), `web_ui_v0.py`(동일) — 요청
  목록 밖이거나 중복. **`web_ui.py`는 2026-07-28부터 포함됐다**(위 §1 참고,
  예전 버전 README는 "웹UI는 안 넣었다"고 했는데 지금은 아니다).
- `cup_detect`의 `probe_grip_v1`(Z 탐지) — v2가 대체.
- `monitor_pjt`의 ament 스타일 테스트(copyright/flake8/pep257) — `verify.sh`가
  게이트에서 제외하는 항목이라 뺐다.

## 9. 파일 지도

| 파일 | 역할 | 만질 일 |
|---|---|---|
| `orchestrator.py` | 플로우·예외처리 | **자주** |
| `coffee_steps.py` | 커피 5단계 + 교시 좌표 + 외력 대기 | 좌표/속도 튜닝 |
| `pose_math.py` | ZYZ 오일러 ↔ 회전벡터/행렬 변환 (4~5단계 경로 생성용) | 거의 안 만짐 |
| `probe_grip.py` | 컵 접촉 탐지·파지 (`run_once(ctx)`) — 공정과 별개 | 탐지 파라미터 튜닝 |
| `gripper.py` | RG2 명령 + 파지 판정 | 판정 임계 튜닝 |
| `robot.py` | DSR 세션·TCP·정지 | 거의 안 만짐 |
| `buttons.py` | DI 13~16 물리 버튼 + 가상 버튼 래치 | 선택지 표 수정 |
| `process_state.py` | 상태머신 정의 + 보고 규약(`detail` 포함) | 공정 순서 바꿀 때 |
| `system_monitor.py` | 로봇 폴링·안전 판정·그리퍼 DO 테스트·1회성 이동 | 모니터/관리자 명령 추가 시 |
| `dashboard.py` | Qt 모니터 창 (로컬) | 위젯 추가 시 |
| `web_ui.py` | 브라우저 UI (고객 화면 + 관리자 화면, FastAPI) | 화면 매핑·명령 추가 시 |
| `snapshot.py` | system_monitor ↔ dashboard/web_ui JSON 스키마 | 필드 추가 시 |
| `test/test_flow_contract.py` | 플로우-상태머신 계약 | 순서 바꾸면 같이 |
| `test/test_web_ui_translate.py` | process_state -> 웹UI 상태 번역 계약 | STEP_TO_SCREEN 바꾸면 같이 |
| `test/test_grind_progress.py` | 분쇄 회전량 누적 로직 | `_grind_arc` 바꾸면 같이 |
| `test/test_retry_stage.py` | 단계 실패 재시도 루프 | `run_stage` 바꾸면 같이 |
| `test/test_gripper_log.py` | rclpy 로거 severity 캐싱 회귀 방지 | |
| `test/test_dashboard.py` | GUI 로직 (offscreen) | |
