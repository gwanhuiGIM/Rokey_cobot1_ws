# 세션 상태

## 2026-07-28
- **공정 5단계로 확정, 4~5단계 추가**: `src/rokey/rokey/coffee_system.py`(원본
  워크스페이스) 최신본을 반영. 2026-07-27의 "6단계 예약표"(컵 서빙 추측)는
  틀렸다 — 실제로는 서빙 단계가 없다. 4) `CoffeeSteps.hand_drip()`(주전자
  파지 -> 위치보상 내향 스파이럴 붓기), 5) `CoffeeSteps.final_pour()`(필터
  홀더+물컵 배치 -> 주둥이 위치 고정 붓기, 시작 자세로 복귀하지 않고 끝남).
  정정 기록: `docs/plans/2026-07-27-full-6-stage-flow.md` 상단.
- **pose_math.py 신설**: 스파이럴/보상 경로에 쓰는 회전행렬·회전벡터·ZYZ
  오일러 변환을 rclpy/DSR SDK 없이 단위 테스트 가능하게 분리.
- **process_state.py에 `detail` 필드 추가**: STEPS 스키마를 안 건드리고
  자유 형식 JSON(그라인더 회전수, 스파이럴/최종붓기 진행률, 외력 등)을
  실을 수 있게 했다 — web_ui.py 고객 화면이 이걸로 구체적인 수치를 보여준다.
- **web_ui.py 신규 (FastAPI)**: 원본 `src/rokey/rokey/web_ui.py`의 HTML/JS는
  그대로 재사용하고, 상태 소스만 폐기된 `/coffee_system/status` ->
  `/coffee_process/state`(단일 채널)로 바꿨다. 관리자 화면은 기존
  system_monitor 토픽(`~/status`,`~/log`,`~/cmd`)에 그대로 붙는다.
  - system_monitor.py에 `move_task`/`move_joint6` 명령을 새로 구현했다
    (admin 화면의 1회성 상대이동 버튼용). tcp_offset 피벗 보상은
    **미구현**(UNVERIFIED, 검증 안 된 수학으로 실기를 왜곡시키지 않기 위해).
  - 그리퍼 버튼은 기존 `system_monitor.gripper(preset)` API에 맞춰
    JS 2줄만 고쳤다(`command:'o'/'c'` -> `preset:'open_wide'/'close'`).
  - fastapi/uvicorn은 pip 전용 의존성(rosdep 키 없음) — README §빌드 참고.
- 검증: `./scripts/verify.sh coffee_pipeline` → 실행 예정(다음 커맨드).
  이번에도 실기 미검증.

### 다음 세션에서 먼저 할 것
- 실기 1 사이클 완주 — 아직 로봇에서 돌려본 적 없다. 특히 4~5단계는 이번에
  처음 포팅된 movesx 기반 위치보상 경로라 실기 검증 우선순위가 높다.
- `robot.py`의 `TOOL_NAME`이 `"Tool Weight123"`으로 되어 있다(원본
  coffee_system.py는 `"Tool Weight_gripper"`) — 실측 후 바뀐 값으로 보여
  이번 세션에서 되돌리지 않았다. 실기에서 어느 쪽이 맞는지 확인할 것.

## 2026-07-27
- **버그 수정**: `orchestrator` 기동 즉시 `'NoneType' object has no attribute 'create_client'`
  → 원인은 이름 맹글링. `Robot.connect()`(클래스 안)의 `DR_init.__dsr__node = node` 가
  `DR_init._Robot__dsr__node` 로 저장됐다. 모듈 레벨 `robot.bind_dsr_node()` 로 이동.
  (`__dsr__id/__model` 은 모듈 레벨 대입이라 멀쩡했던 게 단서)
- **공정 3단계 확정**: 1) 원두(BEAN_DROP) 2) 그라인딩(GRINDING) 3) 갈린 원두 운반
  (BOTTLE_PICK→BOTTLE_MOVE→WAIT_TAP→BOTTLE_RETURN). `CoffeeSteps.dripper_in` →
  `transfer_grounds` 로 개명(앞으로 붙을 실제 '드립' 단계와 이름 충돌 방지).
- **probe_grip 분리**: orchestrator가 더 이상 호출하지 않음. STEPS에서 CUP_* 제거,
  probe_grip은 로그만 남긴다. 단독 실행 진입점은 유지.
- 검증: `./scripts/verify.sh coffee_pipeline` → **VERIFY: PASS** (빌드+테스트).
  실기 미검증(로봇 미연결 상태에서 작업).

### 다음 세션에서 먼저 할 것
- `~/cobot1_ws/install/coffee_pipeline` 은 **옛날 복사본**이다(상위 ws에 소스 없음).
  이게 먼저 잡히면 고친 코드가 안 돈다 → 지우거나, 이 ws의 install을 나중에 source.
- 공정 4~6단계 정의 → `process_state.STEPS`에 스텝 추가 + `CoffeeSteps` 메서드 추가.
  최종 6단계 사양·이름 예약표는 `docs/plans/2026-07-27-full-6-stage-flow.md`.
  5단계가 probe_grip 복귀 자리다 — 오늘 분리한 건 폐기가 아니라 보류다.
