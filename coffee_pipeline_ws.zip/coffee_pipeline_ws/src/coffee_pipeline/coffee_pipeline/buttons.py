# =============================================================
# buttons.py — 컨트롤박스 물리 버튼(DI 13~16) 입력
# -------------------------------------------------------------
# 실행: 라이브러리
# 의존: rclpy, dsr_msgs2/RobotState
# -------------------------------------------------------------
# RobotState 토픽을 우선 쓰고, 안 들어오면 get_digital_input()으로 폴백한다.
# 해제 상태를 0으로 가정하지 않고 "안정된 현재값"을 기준으로 잡기 때문에
# Active-High/Active-Low 배선 둘 다 처리된다 (원본 커피 노드에서 검증된 로직).
#
# 가상 버튼: /coffee_process/button_press (std_msgs/UInt8, 값 = DI 번호)로
#   물리 버튼과 똑같은 효과를 낸다. 컨트롤박스에 손이 안 닿을 때 쓴다.
#     ros2 topic pub --once /coffee_process/button_press std_msgs/msg/UInt8 "{data: 13}"
#   대시보드 "5. IO" 패널의 누르기 버튼도 이 토픽을 그대로 쏜다.
#
# 블로킹 함수다(wait_for_button). 절차형 플로우 안에서만 쓰고, 콜백 안에서
# 부르지 말 것.
# =============================================================

import time

import rclpy
from dsr_msgs2.msg import RobotState
from std_msgs.msg import UInt8

from coffee_pipeline.process_state import BUTTON_PRESS_TOPIC

PHYSICAL_BUTTONS = (13, 14, 15, 16)

# 예외 처리 대기 중에는 같은 DI 13~16을 다른 의미로 재사용한다
# (그 시점엔 원두/굵기 선택 대기가 아니므로 충돌하지 않는다).
RETRY_BUTTON = 13
ABORT_BUTTON = 16

BEAN_BY_BUTTON = {
    13: {"id": "ethiopia", "name": "에티오피아 예가체프"},
    14: {"id": "colombia", "name": "콜롬비아 수프리모"},
    15: {"id": "brazil", "name": "브라질 산토스"},
    16: {"id": "guatemala", "name": "과테말라 안티구아"},
}

# 분쇄 굵기: 1회전 = movec angle 360도 (coffee_steps.DEGREES_PER_GRINDER_TURN).
GRIND_BY_BUTTON = {
    13: {"id": "coarse", "name": "굵게 분쇄", "turns": 3},
    14: {"id": "medium_coarse", "name": "중간 굵게 분쇄", "turns": 5},
    15: {"id": "medium_fine", "name": "중간 곱게 분쇄", "turns": 7},
    16: {"id": "fine", "name": "곱게 분쇄", "turns": 10},
}

POLL_SEC = 0.03
DEBOUNCE_SEC = 0.05
BASELINE_STABLE_SEC = 0.20
STATE_STALE_SEC = 1.00
SOURCE_WAIT_SEC = 3.00

ROBOT_STATE_TYPE = "dsr_msgs2/msg/RobotState"
ROBOT_STATE_TOPIC_CANDIDATES = (
    "/dsr01/msg/robot_state",
    "/dsr01/robot_state",
    "/dsr01/dsr_controller2/robot_state",
)


class PhysicalButtonInput:
    """DI 13~16을 RobotState 우선, get_digital_input() 보조로 감지한다."""

    def __init__(self, node, get_digital_input):
        self._node = node
        self._get_digital_input = get_digital_input
        self._subscriptions = {}
        self._robot_state_buttons = {}
        self._robot_state_stamp = 0.0
        self._source = "uninitialized"
        self._virtual_press = None

        for topic in ROBOT_STATE_TOPIC_CANDIDATES:
            self._register_topic(topic)

        node.create_subscription(UInt8, BUTTON_PRESS_TOPIC, self._on_virtual, 10)

    def _register_topic(self, topic):
        if not topic or topic in self._subscriptions:
            return
        self._subscriptions[topic] = self._node.create_subscription(
            RobotState, topic,
            lambda msg, source=topic: self._on_robot_state(msg, source), 10)
        self._node.get_logger().info(f"RobotState 구독 등록: {topic}")

    def _discover_topics(self):
        try:
            topics = self._node.get_topic_names_and_types()
        except Exception as error:
            self._node.get_logger().warning(f"RobotState 토픽 탐색 실패: {error}")
            return
        for topic, type_names in topics:
            if ROBOT_STATE_TYPE in type_names:
                self._register_topic(topic)

    def _on_robot_state(self, msg, source):
        values = {}
        if hasattr(msg, "controller_digital_input"):
            mask = int(getattr(msg, "controller_digital_input"))
            values = {i: (mask >> (i - 1)) & 0x1 for i in PHYSICAL_BUTTONS}
        elif hasattr(msg, "ctrlbox_digital_input"):
            raw = list(getattr(msg, "ctrlbox_digital_input"))
            if len(raw) >= max(PHYSICAL_BUTTONS):
                values = {i: int(raw[i - 1]) for i in PHYSICAL_BUTTONS}
        if not values:
            return

        self._robot_state_buttons = values
        self._robot_state_stamp = time.monotonic()
        new_source = f"RobotState:{source}"
        if self._source != new_source:
            self._source = new_source
            self._node.get_logger().info(
                f"물리 버튼 입력 소스 전환: {self._source}, raw={values}")

    def _on_virtual(self, msg):
        number = int(msg.data)
        if number not in PHYSICAL_BUTTONS:
            self._node.get_logger().warning(
                f"가상 버튼 무시: DI {number} (허용 {PHYSICAL_BUTTONS})")
            return
        # 래치 1개만 둔다 — 대기 중이 아닐 때 눌러도 다음 대기에서 소비된다.
        self._virtual_press = number
        self._node.get_logger().info(f"가상 버튼 DI {number} 수신")

    def take_virtual_press(self):
        """래치된 가상 버튼을 꺼내고 비운다. 없으면 None."""
        number, self._virtual_press = self._virtual_press, None
        return number

    def _is_fresh(self):
        return (bool(self._robot_state_buttons)
                and time.monotonic() - self._robot_state_stamp <= STATE_STALE_SEC)

    def _wait_for_source(self):
        deadline = time.monotonic() + SOURCE_WAIT_SEC
        self._discover_topics()
        while rclpy.ok():
            rclpy.spin_once(self._node, timeout_sec=0.05)
            self._discover_topics()
            if self._is_fresh():
                return
            if time.monotonic() >= deadline:
                self._node.get_logger().warning(
                    "RobotState DI를 받지 못해 get_digital_input()으로 대체합니다.")
                return

    def read(self):
        rclpy.spin_once(self._node, timeout_sec=0.0)
        self._discover_topics()
        if self._is_fresh():
            return dict(self._robot_state_buttons)

        values = {i: int(self._get_digital_input(i)) for i in PHYSICAL_BUTTONS}
        if self._source != "DSR:get_digital_input":
            self._source = "DSR:get_digital_input"
            self._node.get_logger().warning(
                f"물리 버튼 입력 소스: {self._source}, raw={values}")
        return values

    def _stable_baseline(self):
        self._wait_for_source()
        baseline = None
        stable_since = time.monotonic()
        while rclpy.ok():
            current = self.read()
            now = time.monotonic()
            if baseline != current:
                baseline = dict(current)
                stable_since = now
                self._node.get_logger().info(
                    f"버튼 기준값 확인 ({self._source}): {baseline}")
            if now - stable_since >= BASELINE_STABLE_SEC:
                return dict(baseline)
            time.sleep(POLL_SEC)
        raise KeyboardInterrupt

    def wait_for_button(self, on_poll=None):
        """버튼 1개가 눌렸다 떨어질 때까지 블로킹. 눌린 DI 번호를 반환.

        on_poll: 대기 중 주기적으로 부를 콜백(진행 상태 재발행 등). 예외를
        던지면 그대로 전파된다 — 취소를 이걸로 구현해도 된다.
        """
        baseline = self._stable_baseline()
        self._node.get_logger().info(
            f"DI 13~16 버튼 입력 대기: source={self._source}, baseline={baseline}, "
            f"가상 버튼={BUTTON_PRESS_TOPIC}")

        while rclpy.ok():
            if on_poll is not None:
                on_poll()
            current = self.read()          # spin_once 포함 -> 가상 버튼 콜백도 여기서 들어온다
            virtual = self.take_virtual_press()
            if virtual is not None:
                self._node.get_logger().info(f"가상 버튼 DI {virtual} 채택 (해제 대기 없음)")
                return virtual
            changed = [i for i in PHYSICAL_BUTTONS if current[i] != baseline[i]]
            if changed:
                index = changed[0]
                time.sleep(DEBOUNCE_SEC)
                if self.read()[index] != baseline[index]:
                    self._node.get_logger().info(f"물리 버튼 DI {index} 감지")
                    while rclpy.ok():
                        if self.read()[index] == baseline[index]:
                            self._node.get_logger().info(f"물리 버튼 DI {index} 해제 확인")
                            return index
                        time.sleep(POLL_SEC)
            time.sleep(POLL_SEC)
        raise KeyboardInterrupt


# --- self-check: 가상 버튼 래치만 검증 (ROS/로봇 불필요) -------------------
# 실행: python3 -m coffee_pipeline.buttons --selftest

def _demo():
    class _StubLogger:
        def info(self, _text): pass
        warning = info

    class _StubNode:
        def get_logger(self): return _StubLogger()
        def create_subscription(self, *_a, **_k): return None

    buttons = PhysicalButtonInput(_StubNode(), lambda _i: 0)
    assert buttons.take_virtual_press() is None

    buttons._on_virtual(UInt8(data=14))
    assert buttons.take_virtual_press() == 14
    assert buttons.take_virtual_press() is None      # 1회 소비 후 비어야 한다

    buttons._on_virtual(UInt8(data=99))              # 범위 밖은 래치되지 않는다
    assert buttons.take_virtual_press() is None

    buttons._on_virtual(UInt8(data=13))
    buttons._on_virtual(UInt8(data=16))              # 마지막 것만 남는다(큐 아님)
    assert buttons.take_virtual_press() == 16
    print("buttons self-check OK")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--selftest":
        _demo()
