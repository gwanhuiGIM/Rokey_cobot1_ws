# =============================================================
# coffee_steps.py — 커피 추출 5단계 전체 공정
#   1) bean_drop()        원두: 스푼 파지 -> 그라인더 호퍼 투입
#   2) grinder(turns)     그라인딩: 손잡이 파지 -> 회전 분쇄
#   3) transfer_grounds() 갈린 원두 운반: 병 파지 -> 이송/붓기 -> 외력 감지 -> 복귀
#   4) hand_drip()         핸드드립: 주전자 파지 -> 위치보상 내향 스파이럴 붓기 -> 반환
#   5) final_pour()        최종 붓기: 필터홀더+물컵 배치 -> Joint6 등가 기울임 붓기
#      (final_pour는 시작 자세로 복귀하지 않는다 — 기울어진 자세가 사이클의 끝)
# -------------------------------------------------------------
# 실행: 라이브러리 (모션은 orchestrator.py가 호출)
# 의존: robot.Robot, gripper.Gripper, pose_math, numpy, process_state.ProcessReporter(선택)
# -------------------------------------------------------------
# 원본: src/coffee_system/coffee_system/m0609_coffee_system_v2.py (1~3단계, main() 한 덩어리)
#       + src/rokey/rokey/coffee_system.py (4~5단계 추가분, 2026-07-28 반영)
# 통합 시 바뀐 것
#  1. main() 안의 지역 함수였던 서브루틴들을 클래스 메서드로 꺼냈다 —
#     플로우(선택·재시도·중단)를 바깥에서 짤 수 있게 하려고.
#  2. 그리퍼 DO 접점 조합 -> gripper.Gripper (probe_grip과 공유, 파지 판정 포함).
#     원본 hand_drip/final_pour(spiral_pour/final_drip)는 파지 판정이 없었는데,
#     이 프로젝트의 grip_close() 전부에 적용하는 정책(결정 4)을 여기도 맞췄다.
#  3. 웹UI용 StatusReporter(/coffee_system/status JSON) 제거 ->
#     process_state.ProcessReporter(/coffee_process/state)로 일원화. 웹UI
#     (web_ui.py)는 이 채널을 구독하는 쪽으로 다시 붙었다 — README §아키텍처.
#  4. grip 닫기 지점마다 파지 판정을 넣었다 (docs/GRIP_DETECTION.md §4).
#     실패 시 GripFailed를 던진다 — 놓친 채 다음 모션으로 가면 낙하 위험.
#  5. 스파이럴/보상 경로 수학(회전행렬·회전벡터·오일러 변환)은 pose_math.py로
#     뺐다 — rclpy/DSR SDK 없이도 단위 테스트가 되고, web_ui 등 비-모션
#     프로세스에서도 재사용 가능하게.
#  6. movesx() 시그니처는 이 환경에서 inspect.signature()로 실측 확인했다
#     (kwargs: pos_list, vel, acc, time, ref, mod, vel_opt). 원본의 4단계
#     폴백(위치인자까지 시도)은 미확인 구버전 대비였는데, 실측 확인됐으니
#     kwargs 2단계(시간지정 -> 실패시 속도/가속도+시간)로 줄였다.
#
# 교시 좌표(System_*)는 원본 System.drvar/coffee_system.py 값 그대로다.
# 작업물(그라인더/드리퍼/병/컵/스푼/주전자/필터홀더/물컵) 위치가 교시 당시와
# 다르면 전부 틀린다 — README §튜닝 표 참고.
# =============================================================

import math
import time

import numpy as np
import rclpy

from coffee_pipeline import pose_math as pm
from coffee_pipeline.gripper import GripFailed
from coffee_pipeline.robot import TCP_NAME

# --- 교시 포즈 (원본 System.drvar) --------------------------------------
# posj = 관절각 6개[deg], posx = [x,y,z(mm), A,B,C(deg)]
SPOON_J = [-69.6, 53.27, 96.56, 25.63, 114.79, -171.03]
SPOON_L = [251.01, -118.46, 40.17, 87.01, 92.73, -3.35]
SPOON_L_RELEASE = [251.01, -118.46, 50.17, 87.01, 92.73, -3.35]
GRINDER_J = [-40.58, -9.25, 131.96, 78.44, 107.42, -125.46]
GRINDER_L = [371.82, 168.64, 360.0, 61.05, 86.52, 56.67]
GRIND_READY_J = [13.43, 31.67, 32.98, 0.19, 115.35, 11.45]
HANDLE_J = [15.05, 35.75, 18.15, -1.7, 124.03, 13.38]
HANDLE_L = [527.43, 129.24, 278.22, 121.84, -180.0, 120.1]
BOTTLE_J_1 = [-19.18, 34.8, 22.24, -2.53, 124.42, -13.34]
BOTTLE_J_2 = [-43.18, 55.32, 88.81, 53.44, 114.38, -60.57]
BOTTLE_L = [401.53, 167.78, 71.68, 92.22, 89.54, 89.25]
BOTTLE_L_RELEASE = [401.53, 167.78, 76.68, 92.22, 89.54, 89.25]
DRIP_J = [-26.64, 44.1, 73.65, 89.85, 91.27, -26.21]
DRIP_L = [751.71, 41.51, 238.65, 60.13, 91.27, -92.13]
HOME_J = [-71.33, 47.91, 97.52, 18.17, 114.49, -168.37]

# --- 분쇄 --------------------------------------------------------------
DEGREES_PER_GRINDER_TURN = 360.0
GRIND_USER_COORD = 101          # 티치펜던트에 등록된 사용자 좌표계
GRIND_STIFFNESS = [1500.0, 1500.0, 2500.0, 150.0, 150.0, 200.0]
GRIND_ARC_VIA = [0.0, -124.5, -5.0, 90.0, -179.99, 88.27]
GRIND_ARC_END = [-124.5, 0.0, -5.0, 90.0, -179.99, 88.27]
GRIND_PROGRESS_POLL_SEC = 0.10  # 회전량 측정 주기. 낮추면 서비스 호출 부하가 는다
GRIND_START_TIMEOUT_SEC = 2.0   # amovec가 실제로 움직이기 시작할 때까지 기다리는 한계


def _wrap_pi(angle):
    """각도차를 [-pi, pi)로 정규화. 원호가 ±180°를 넘을 때 부호 튐 방지."""
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


# --- 드립 후 "병 두드림" 외력 감지 ---------------------------------------
FORCE_TRIGGER_N = 4.0           # 기준 대비 이만큼 변하면 사람이 쳤다고 판정
FORCE_SETTLE_SEC = 0.60         # move_periodic 잔류 진동이 가라앉을 시간
FORCE_BASELINE_SAMPLES = 20
FORCE_SAMPLE_SEC = 0.02
FORCE_CONFIRM_SAMPLES = 2       # 연속 이만큼 임계 초과해야 확정
FORCE_REPORT_SEC = 0.20         # 모니터로 현재 외력을 다시 알리는 주기

DRIP_PERIODIC_AMP = [0.0, 0.0, 0.0, 2.0, 0.0, 0.0]
DRIP_PERIODIC_PERIOD = [1.0, 1.0, 1.0, 0.3, 1.0, 1.0]
DRIP_PERIODIC_REPEAT = 5
DRIP_TCP_NAME = "joint4"        # 드립 흔들기 동안만 쓰는 TCP

# --- 4단계: 핸드드립 (주전자 파지 -> 내향 스파이럴 붓기) ------------------
# 교시 좌표 (원본 SYSTEM_POT_GRIP_VALUES 등, coffee_system.py 그대로)
POT_GRIP_L = [831.36, -177.93, 108.26, 3.26, 90.23, 86.66]
POT_GRIP_J = [-28.73, 38.17, 112.55, 146.06, 65.17, -73.99]
POUR_START_J = [-13.00, 23.41, 100.08, 144.04, 35.00, -122.57]
POT_PICKUP_APPROACH_REL = [0.0, -80.0, 100.0, 0.0, 0.0, 0.0]
POT_PICKUP_LIFT_REL = [-150.0, 0.0, 200.0, 0.0, 0.0, 0.0]

SPOUT_TCP_NAME = "pot"          # 주전자 주둥이 TCP (스파이럴 동안만)
SPIRAL_RADIUS_MM = 44.0
SPIRAL_REVOLUTIONS = 5.0
SPIRAL_DURATION_SEC = 15.0
SPIRAL_J6_DELTA_DEG = -60.0     # 주전자를 기울이는 가상 J6 회전량(등가)
SPIRAL_PATH_POINTS = 100
SPIRAL_CENTER_OFFSET_SIGN_X = -1.0
SPIRAL_ROTATION_SIGN = 1.0

CENTER_PIVOT_RETURN_DURATION_SEC = 3.0
CENTER_PIVOT_RETURN_POINTS = 30

POT_RELEASE_BASE_Z_OFFSET_MM = 10.0   # 내려놓기 전 Base +Z 여유
POT_RELEASE_SETTLE_SEC = 0.8

# movesx 경로 검증 한계 — 넘으면 경로 생성이 잘못된 것으로 보고 즉시 중단
MOVESX_MAX_LINEAR_STEP_MM = 15.0
MOVESX_MAX_ANGULAR_STEP_DEG = 5.0
MOVESX_LINEAR_VEL_MM_S = 120.0
MOVESX_ANGULAR_VEL_DEG_S = 25.0
MOVESX_LINEAR_ACC_MM_S2 = 300.0
MOVESX_ANGULAR_ACC_DEG_S2 = 80.0

# --- 5단계: 최종 물 붓기 (필터 홀더 배치 -> 물컵 파지 -> 위치보상 붓기) ----
FILTER_HOLDER_J = [-30.99, 52.68, 70.94, 74.39, 112.41, -306.08]
FILTER_HOLDER_L = [653.6, 17.98, 181.99, 85.67, 90.12, -179.93]
FILTER_HOLDER_PLACE_L = [349.44, 4.5, 96.59, 90.83, 90.78, 174.75]
MUG_J = [-32.73, 54.93, 83.19, 82.8, 93.84, -10.72]
MUG_L = [655.06, 48.93, 82.17, 70.19, 92.83, 123.59]
FINAL_POUR_L = [699.92, -319.33, 332.35, 26.41, 87.7, 167.11]
FINAL_POUR_J2 = [-53.67, 53.18, 48.53, 96.63, 74.0, 146.0]
FINAL_POUR_APPROACH_J = [-50.40, 31.33, 84.53, 98.98, 78.15, 40.42]
FINAL_POUR_APPROACH_DURATION_SEC = 9.33   # movej_with_time — DRL 원본 타이밍

FINAL_POUR_TCP_NAME = "mug"
FINAL_POUR_SPOUT_OFFSET_TOOL_MM = np.array([1.0, 1.0, 1.0], dtype=float)
FINAL_POUR_J6_DELTA_DEG = 45.0
FINAL_POUR_DURATION_SEC = 8.0
FINAL_POUR_PATH_POINTS = 100
FINAL_POUR_MAX_LINEAR_STEP_MM = 5.0
FINAL_POUR_MAX_ANGULAR_STEP_DEG = 3.0
FINAL_POUR_MOVESX_LINEAR_VEL_MM_S = 40.0
FINAL_POUR_MOVESX_ANGULAR_VEL_DEG_S = 15.0
FINAL_POUR_MOVESX_LINEAR_ACC_MM_S2 = 120.0
FINAL_POUR_MOVESX_ANGULAR_ACC_DEG_S2 = 40.0
FINAL_POUR_SPOUT_ERROR_WARN_MM = 3.0  # 이 이상 오차 나면 TCP/오프셋 재확인 경고

# final_pour 진입 시에만 적용하는 전역 모션 파라미터 (DRL final_drip 하단 설정).
# 마지막 서브루틴부터 끝까지 적용되고 복원하지 않는다 — 원본과 동일 동작
# (사이클이 여기서 끝나고 다음 사이클은 apply_motion_defaults()로 다시 잡는다).
FINAL_DRIP_VELJ = 60.0
FINAL_DRIP_ACCJ = 100.0
FINAL_DRIP_VELX_LIN = 250.0
FINAL_DRIP_VELX_ROT = 80.625
FINAL_DRIP_ACCX_LIN = 1000.0
FINAL_DRIP_ACCX_ROT = 322.5


class CoffeeSteps:
    """커피 공정 서브루틴. 각 메서드는 블로킹이고 예외를 그대로 올린다."""

    def __init__(self, robot, gripper, report=None, verify_grip=True):
        self.robot = robot
        self.d = robot.dsr
        self.log = robot.log
        self.gripper = gripper
        self.report = report
        self.verify_grip = verify_grip

    # ---------- 내부 헬퍼 ----------

    def _say(self, step, message="", progress_in_step=None, waiting=None, detail=None):
        if self.report is not None:
            self.report.set(step, message, progress_in_step, waiting, detail)

    def _grip(self, what, verify=None):
        """닫고 파지 확인. 실패하면 GripFailed (호출자가 정지/재시도 결정)."""
        verify = self.verify_grip if verify is None else verify
        if not verify:
            self.gripper.close()
            time.sleep(1.0)
            return
        held, reason = self.gripper.close_and_verify(what)
        if not held:
            raise GripFailed(f"{what} 파지 실패: {reason}")

    def _movej(self, joints, **kwargs):
        d = self.d
        d.movej(d.posj(joints), radius=0.0, ra=d.DR_MV_RA_DUPLICATE, **kwargs)

    def _movel_abs(self, pose):
        d = self.d
        d.movel(d.posx(pose), radius=0.0, ref=d.DR_BASE,
                mod=d.DR_MV_MOD_ABS, ra=d.DR_MV_RA_DUPLICATE)

    def _movel_rel(self, delta, ref=None):
        d = self.d
        d.movel(d.posx(delta), radius=0.0, ref=d.DR_BASE if ref is None else ref,
                mod=d.DR_MV_MOD_REL, ra=d.DR_MV_RA_DUPLICATE)

    # ---------- 공정 ----------

    def home(self):
        self._say("HOME")
        self.gripper.open_cup()
        self._movej(HOME_J)

    def bean_drop(self):
        """스푼을 잡고 원두를 퍼서 그라인더 호퍼에 투입."""
        d = self.d
        self._say("BEAN_DROP", "스푼 파지")
        self.gripper.open_cup()
        self._movej(HOME_J)

        self._movej(SPOON_J)
        self._movel_abs(SPOON_L)
        self._grip("스푼")

        self._say("BEAN_DROP", "그라인더로 이동", progress_in_step=0.3)
        self._movel_rel([0.0, 0.0, 100.0, 0.0, 0.0, 0.0])
        self._movej(GRINDER_J)
        self._movel_abs(GRINDER_L)

        self._say("BEAN_DROP", "원두 투입", progress_in_step=0.6)
        d.amovel(d.posx([32.0, -15.0, 0.0, 0.0, 0.0, 0.0]), time=1.0,
                 ref=d.DR_BASE, mod=d.DR_MV_MOD_REL, ra=d.DR_MV_RA_DUPLICATE)
        d.movej(d.posj([0.0, 0.0, 0.0, 0.0, 0.0, 45.0]), time=1.0, radius=0.0,
                mod=d.DR_MV_MOD_REL, ra=d.DR_MV_RA_DUPLICATE)
        self._movel_rel([0.0, 0.0, 5.0, 0.0, 0.0, 0.0])
        self._movej(GRINDER_J)

        self._say("BEAN_DROP", "스푼 내려놓기", progress_in_step=0.85)
        self._movel_abs(SPOON_L_RELEASE)
        self._movel_rel([0.0, 0.0, -10.0, 0.0, 0.0, 0.0])
        self.gripper.open_cup()
        d.wait(1.0)
        self._movej(HOME_J)

    def _grind_arc(self, grind_turns):
        """원호를 돌리면서 **실제** 회전량을 진행률로 보고한다 (블로킹).

        블로킹 movec 한 방이면 수십 초 동안 보고가 끊겨 모니터가 "스텝 정체"로
        본다. amovec로 던져 놓고 좌표계 101의 X/Y 각도를 폴링해 누적한다 —
        컴플라이언스 때문에 명령 각도와 실제 각도가 어긋나므로 실측이 맞다.
        """
        d = self.d
        via_angle = math.atan2(GRIND_ARC_VIA[1], GRIND_ARC_VIA[0])

        pose, _ = d.get_current_posx(ref=GRIND_USER_COORD)
        last = math.atan2(pose[1], pose[0])
        # 현재점 -> 경유점 방향이 곧 원호 진행 방향.
        # UNVERIFIED: 시작 자세가 경유점과 거의 정반대(Δ≈±180°)면 부호가 뒤집힌다.
        #   GRIND_READY_J 자세에서 실기 확인 필요 (README §미검증).
        direction = -1.0 if _wrap_pi(via_angle - last) < 0.0 else 1.0

        d.amovec(d.posx(GRIND_ARC_VIA), d.posx(GRIND_ARC_END), radius=0.0,
                 ref=GRIND_USER_COORD,
                 angle=[DEGREES_PER_GRINDER_TURN * grind_turns, 0.0],
                 ra=d.DR_MV_RA_OVERRIDE)

        net = 0.0
        travelled = 0.0
        moving = False
        posx_warned = False
        start_deadline = time.monotonic() + GRIND_START_TIMEOUT_SEC
        while rclpy.ok():
            # 실측(coffee_system_v3 대비 확인): DSR_ROBOT2.check_motion()/
            # get_current_posx()는 서비스 future가 실패해도 -1이나 (None,None)을
            # 안전하게 주지 않는다 — check_motion은 except에서 ret을 못 채운 채
            # return해 UnboundLocalError, get_current_posx는 bare 0을 반환해
            # `pose, _ = 0` 언패킹이 TypeError로 죽는다(DSR_ROBOT2.py 3826/974행).
            # try 없이 부르면 그 순간 분쇄 전체가 죽는다.
            try:
                state = d.check_motion()
            except Exception as error:
                self.log.warning(f"check_motion() 실패 — 모션 종료만 기다립니다: {error}")
                break
            if state < 0:
                self.log.warning("분쇄 진행률 측정 실패 — 모션 종료만 기다립니다.")
                break

            try:
                pose, _ = d.get_current_posx(ref=GRIND_USER_COORD)
                if pose is None:
                    raise RuntimeError("get_current_posx() 응답 없음")
                angle = math.atan2(pose[1], pose[0])
                net += direction * _wrap_pi(angle - last)
                last = angle
                # 순증분을 그대로 더한다(진동은 상쇄됨). 전진분만 골라 더하면
                # 왕복 진동의 복귀 스트로크가 매번 새 진행량으로 잡혀 부풀려진다.
                # 표시는 뒤로 가지 않게 최대값만 유지.
                travelled = max(travelled, net)
                turns = min(travelled / (2.0 * math.pi), float(grind_turns))
                self._say("GRINDING", f"{turns:.1f}/{grind_turns}회전 분쇄 중",
                          progress_in_step=0.2 + 0.75 * turns / grind_turns)
            except Exception as error:
                # check_motion으로 모션이 계속 도는 건 확인됐다 — 이번 각도
                # 샘플만 건너뛰고 마지막 진행률을 유지한다(break하면 실제로는
                # 계속 도는데 표시만 중간에 멈춘다). 매 폴링마다 경고하면
                # 로그가 넘치므로 1회만 남긴다.
                if not posx_warned:
                    self.log.warning(f"분쇄 각도 측정 실패 — 마지막 진행률 유지: {error}")
                    posx_warned = True

            if state != d.DR_STATE_IDLE:
                moving = True
            elif moving:                      # 움직였다가 멈춤 = 원호 완료
                break
            elif time.monotonic() > start_deadline:
                self.log.warning("amovec 시작을 확인하지 못했습니다 — 모션 종료만 기다립니다.")
                break
            time.sleep(GRIND_PROGRESS_POLL_SEC)

        d.mwait(0)                            # 이미 끝났으면 즉시 리턴

    def grinder(self, grind_turns):
        """선택된 회전 수만큼 그라인더 손잡이를 돌려 분쇄."""
        d = self.d
        if grind_turns <= 0:
            raise ValueError(f"그라인더 회전 수는 1 이상이어야 합니다: {grind_turns}")
        self._say("GRINDING", f"손잡이 파지 ({grind_turns}회전)")
        self._movej(HANDLE_J)
        self.gripper.open_jar()
        self._movel_abs(HANDLE_L)
        self._grip("그라인더 손잡이")

        self._movej(GRIND_READY_J)

        self._say("GRINDING", f"{grind_turns}회전 분쇄 중", progress_in_step=0.2)
        d.task_compliance_ctrl()
        d.set_stiffnessx(GRIND_STIFFNESS, time=0.5)
        try:
            # ori/app_type 키워드는 실제 amovec() 시그니처에 없다 (원본에서 제거됨).
            self._grind_arc(grind_turns)
        finally:
            # 예외로 빠져나가도 손잡이를 40N으로 문 채 멈추면 안 된다.
            d.release_compliance_ctrl()
            self.gripper.open_jar()

        self._say("GRINDING", "분쇄 완료", progress_in_step=0.95)

    def transfer_grounds(self, on_wait_tap=None):
        """3단계: 갈린 원두 운반. 병 파지 -> 드리퍼 위 주기 운동 -> 외력 감지 -> 복귀.

        on_wait_tap: 외력 대기 중 매 샘플마다 부를 콜백(delta_n, peak_n).
                     None이면 report로만 알린다.
        """
        d = self.d
        self._say("BOTTLE_PICK", "병 파지")
        self._movej(BOTTLE_J_1)
        self._movej(BOTTLE_J_2)
        self._movel_abs(BOTTLE_L)
        self._grip("드립 병")
        self._movel_rel([0.0, 0.0, 5.0, 0.0, 0.0, 0.0])

        self._say("BOTTLE_MOVE", "드리퍼로 이동")
        self._movej(BOTTLE_J_2)
        self._movel_rel([0.0, 0.0, 300.0, 0.0, 0.0, 0.0])
        self._movej(DRIP_J)
        self._movel_abs(DRIP_L)
        # 실패해도 계속 간다 — 병을 든 채 여기서 멈추는 게 더 위험할 수 있다.
        if not self.robot.apply_tcp(DRIP_TCP_NAME):
            self.log.warning(f"TCP '{DRIP_TCP_NAME}' 전환 실패 — 기본 TCP로 흔든다")

        self._say("BOTTLE_MOVE", "주기 운동 추출", progress_in_step=0.5)
        d.move_periodic(amp=DRIP_PERIODIC_AMP, period=DRIP_PERIODIC_PERIOD,
                        atime=0.0, repeat=DRIP_PERIODIC_REPEAT, ref=d.DR_TOOL)

        detected = self.wait_for_external_force(on_sample=on_wait_tap)

        self._say("BOTTLE_RETURN", f"{detected:.1f} N 감지 — 병 복귀")
        self.robot.apply_tcp(TCP_NAME)   # 드립용 TCP -> 기본 TCP 복귀
        self._movel_rel([0.0, 0.0, -150.0, 0.0, 0.0, 0.0], ref=d.DR_TOOL)
        self._movej(BOTTLE_J_2)
        self._movel_abs(BOTTLE_L_RELEASE)
        self.gripper.open_jar()
        return detected

    # ---------- movesx 보상 경로 헬퍼 (4~5단계 공용) ----------

    def _current_pose_base(self, label):
        return pm.numeric6(self.d.get_current_posx(ref=self.d.DR_BASE), label=label)

    def _current_joint(self, label="현재 joint pose"):
        return pm.numeric6(self.d.get_current_posj(), label=label)

    def _forward_kinematics_base(self, joint_deg, label="fkin 결과"):
        joint_pose = self.d.posj(*[float(v) for v in joint_deg[:6]])
        return pm.numeric6(self.d.fkin(joint_pose, ref=self.d.DR_BASE), label=label)

    def _validate_movesx_path(self, start_pose, numeric_path, label,
                              max_linear_mm, max_angular_deg):
        if not numeric_path:
            raise RuntimeError(f"{label} 경로가 비어 있습니다.")
        previous = start_pose
        max_linear_step = max_angular_step = 0.0
        for index, point in enumerate(numeric_path, start=1):
            if point.shape != (6,) or not np.all(np.isfinite(point)):
                raise RuntimeError(f"{label} 경유점 {index}가 올바르지 않습니다: {point!r}")
            linear_step = float(np.linalg.norm(point[:3] - previous[:3]))
            angular_step = pm.rotation_distance_deg(previous[3:], point[3:])
            max_linear_step = max(max_linear_step, linear_step)
            max_angular_step = max(max_angular_step, angular_step)
            previous = point
        self.log.info(
            f"{label} 경로 검증: points={len(numeric_path)}, "
            f"max linear step={max_linear_step:.3f} mm, "
            f"max angular step={max_angular_step:.3f} deg")
        if max_linear_step > max_linear_mm:
            raise RuntimeError(f"{label} 경유점 병진 간격이 너무 큽니다: {max_linear_step:.3f} mm")
        if max_angular_step > max_angular_deg:
            raise RuntimeError(f"{label} 경유점 회전 간격이 너무 큽니다: {max_angular_step:.3f} deg")

    def _call_movesx(self, path, duration_sec,
                     linear_vel=MOVESX_LINEAR_VEL_MM_S, angular_vel=MOVESX_ANGULAR_VEL_DEG_S,
                     linear_acc=MOVESX_LINEAR_ACC_MM_S2, angular_acc=MOVESX_ANGULAR_ACC_DEG_S2):
        """movesx() 실행. time=만으로 실패하면 vel/acc를 같이 준다 (실측: 시그니처
        자체는 kwargs로 확인됐지만 어느 조합이 컨트롤러에 통과되는지는 미검증)."""
        d = self.d
        kwargs = dict(ref=d.DR_BASE, mod=d.DR_MV_MOD_ABS, vel_opt=d.DR_MVS_VEL_NONE)
        try:
            result = d.movesx(path, time=duration_sec, **kwargs)
        except TypeError:
            result = d.movesx(path, vel=[linear_vel, angular_vel],
                              acc=[linear_acc, angular_acc], time=duration_sec, **kwargs)
        if isinstance(result, (int, float)) and result < 0:
            raise RuntimeError(f"movesx 실패 반환값={result}")
        return result

    # ---------- 4단계: 핸드드립 (스파이럴) ----------

    def hand_drip(self):
        """주전자를 파지하고 내향 스파이럴 경로로 붓는다 -> 원래 자리에 반환.

        경로 생성: 시작 자세에서 Joint6만 SPIRAL_J6_DELTA_DEG 만큼 돌렸다고
        가정한 가상 목표 자세를 fkin으로 구해 그로 인한 주둥이 Base 변위를
        구하고, 스파이럴이 진행되며 그 변위를 정확히 상쇄하도록 XYZ를 고정한
        채(hold_z, 나선은 center 주위 반경만 줄임) 자세만 보간한다 — 결과적으로
        주둥이 끝은 제자리에서 기울어지며 안쪽으로 좁아지는 나선을 그린다.
        """
        d = self.d
        self._say("HAND_DRIP", "주전자 파지", detail={"spiral_stage": "주전자 파지", "spiral_progress": 5.0})
        self.robot.apply_tcp(TCP_NAME)
        self._movej(BOTTLE_J_2)
        self._movel_rel(POT_PICKUP_APPROACH_REL)
        self._movej(POT_GRIP_J)
        self.gripper.open_wide()
        time.sleep(0.30)
        self._movel_abs(POT_GRIP_L)
        self._grip("주전자")
        self._movel_rel(POT_PICKUP_LIFT_REL)
        self._movej(POUR_START_J)

        self._say("HAND_DRIP", "스파이럴 경로 준비", progress_in_step=0.2,
                  detail={"spiral_stage": "경로 준비", "spiral_progress": 20.0})
        if not self.robot.apply_tcp(SPOUT_TCP_NAME):
            raise RuntimeError(f"주둥이 TCP '{SPOUT_TCP_NAME}' 적용 실패")

        start_pose = self._current_pose_base("현재 TCP Base pose")
        start_joint = self._current_joint()
        final_joint = start_joint.copy()
        final_joint[5] += SPIRAL_J6_DELTA_DEG
        final_virtual_pose = self._forward_kinematics_base(final_joint)

        center_x = start_pose[0] + SPIRAL_CENTER_OFFSET_SIGN_X * SPIRAL_RADIUS_MM
        center_y = start_pose[1]
        hold_z = start_pose[2]

        start_rotation = pm.zyz_to_rotm(start_pose[3:])
        final_rotation = pm.zyz_to_rotm(final_virtual_pose[3:])
        relative_rotvec = pm.rotm_to_rotvec(start_rotation.T @ final_rotation)

        # 등호간격(호길이 균등) 나선 표본: 조밀한 스파이럴을 촘촘히 그려 누적
        # 호길이로 재표본화한다 — 각도(s) 균등 표본은 반경이 줄수록 점간
        # 거리가 좁아져(원둘레 ∝ 반경) 안쪽에서 과밀·바깥에서 성기게 찍힌다.
        dense_count = max(4000, SPIRAL_PATH_POINTS * 80)
        dense_s = np.linspace(0.0, 1.0, dense_count + 1, dtype=float)
        dense_radius = SPIRAL_RADIUS_MM * (1.0 - dense_s)
        dense_theta = SPIRAL_ROTATION_SIGN * 2.0 * math.pi * SPIRAL_REVOLUTIONS * dense_s
        dense_xyz = np.column_stack((
            center_x + dense_radius * np.cos(dense_theta),
            center_y + dense_radius * np.sin(dense_theta),
            np.full_like(dense_s, hold_z),
        ))
        cumulative_length = np.concatenate((
            [0.0], np.cumsum(np.linalg.norm(np.diff(dense_xyz, axis=0), axis=1))))
        total_path_length = float(cumulative_length[-1])
        if not math.isfinite(total_path_length) or total_path_length <= 0.0:
            raise RuntimeError(f"스파이럴 호길이 계산 실패: {total_path_length}")
        target_lengths = np.linspace(
            total_path_length / float(SPIRAL_PATH_POINTS), total_path_length,
            SPIRAL_PATH_POINTS, dtype=float)
        spiral_s_samples = np.interp(target_lengths, cumulative_length, dense_s)

        numeric_path, path, previous_abc = [], [], start_pose[3:].copy()
        for index, spiral_s in enumerate(spiral_s_samples, start=1):
            radius = SPIRAL_RADIUS_MM * (1.0 - float(spiral_s))
            theta = SPIRAL_ROTATION_SIGN * 2.0 * math.pi * SPIRAL_REVOLUTIONS * float(spiral_s)
            orientation_progress = pm.smoothstep5(index / float(SPIRAL_PATH_POINTS))
            target_rotation = start_rotation @ pm.rotvec_to_rotm(
                relative_rotvec * orientation_progress)
            target_abc = pm.rotm_to_zyz_near(target_rotation, previous_abc)
            previous_abc = target_abc
            target = np.array([
                center_x + radius * math.cos(theta), center_y + radius * math.sin(theta), hold_z,
                target_abc[0], target_abc[1], target_abc[2],
            ], dtype=float)
            numeric_path.append(target)
            path.append(d.posx(*[float(v) for v in target]))

        self._validate_movesx_path(start_pose, numeric_path, "스파이럴",
                                   MOVESX_MAX_LINEAR_STEP_MM, MOVESX_MAX_ANGULAR_STEP_DEG)

        self._say("HAND_DRIP", f"{SPIRAL_REVOLUTIONS:.0f}회 스파이럴 붓기 중", progress_in_step=0.4,
                  detail={"spiral_stage": "스파이럴 드립", "spiral_progress": 35.0,
                          "spiral_radius_mm": SPIRAL_RADIUS_MM,
                          "spiral_revolutions": SPIRAL_REVOLUTIONS,
                          "spiral_duration_sec": SPIRAL_DURATION_SEC})
        self._call_movesx(path, SPIRAL_DURATION_SEC)
        end_pose = self._current_pose_base("스파이럴 완료 pose")

        # 스파이럴 중심에서 주둥이 XYZ는 고정한 채 주전자 자세만 시작 자세로 복원.
        self._say("HAND_DRIP", "중심 고정 자세 복원", progress_in_step=0.75,
                  detail={"spiral_stage": "중심 고정 자세 복원", "spiral_progress": 75.0})
        current_rotation = pm.zyz_to_rotm(end_pose[3:])
        target_rotation = pm.zyz_to_rotm(start_pose[3:])
        return_rotvec = pm.rotm_to_rotvec(current_rotation.T @ target_rotation)
        if math.degrees(float(np.linalg.norm(return_rotvec))) >= 0.05:
            fixed_center_xyz = end_pose[:3].copy()
            return_numeric_path, return_path, previous_abc = [], [], end_pose[3:].copy()
            for index in range(1, CENTER_PIVOT_RETURN_POINTS + 1):
                progress_value = pm.smoothstep5(index / float(CENTER_PIVOT_RETURN_POINTS))
                interpolated_rotation = current_rotation @ pm.rotvec_to_rotm(
                    return_rotvec * progress_value)
                target_abc = pm.rotm_to_zyz_near(interpolated_rotation, previous_abc)
                previous_abc = target_abc
                target = np.array([*fixed_center_xyz, *target_abc], dtype=float)
                return_numeric_path.append(target)
                return_path.append(d.posx(*[float(v) for v in target]))
            self._validate_movesx_path(end_pose, return_numeric_path, "중심 고정 자세복원",
                                       MOVESX_MAX_LINEAR_STEP_MM, MOVESX_MAX_ANGULAR_STEP_DEG)
            self._call_movesx(return_path, CENTER_PIVOT_RETURN_DURATION_SEC)

        self._say("HAND_DRIP", "주전자 반환", progress_in_step=0.9,
                  detail={"spiral_stage": "주전자 반환", "spiral_progress": 90.0})
        if not self.robot.apply_tcp(TCP_NAME):
            raise RuntimeError(f"기본 TCP '{TCP_NAME}' 복원 실패")
        self._movej(POT_GRIP_J)
        release_values = [float(v) for v in POT_GRIP_L]
        release_values[2] += POT_RELEASE_BASE_Z_OFFSET_MM
        self._movel_abs(release_values)
        self.gripper.open_wide()
        time.sleep(POT_RELEASE_SETTLE_SEC)
        self._say("HAND_DRIP", "핸드드립 완료", progress_in_step=0.99,
                  detail={"spiral_stage": "완료", "spiral_progress": 100.0})

    # ---------- 5단계: 최종 물 붓기 ----------

    def final_pour(self):
        """필터 홀더 배치 -> 물컵 파지 -> 주둥이 Base XYZ 고정 위치보상 붓기.

        Joint6를 FINAL_POUR_J6_DELTA_DEG 만큼 가상 회전했을 때 생기는 주둥이
        변위를 TCP 병진으로 역보상한 경로를 만들어, 실제로는 주둥이 끝이
        허공에 고정된 채 컵만 기울어지는 것처럼 보이게 한다 (hand_drip의
        고정-스파이럴과 같은 기법, 반경이 0인 특수 케이스).

        원본과 동일하게 붓기 후 시작 자세로 복귀하지 않는다 — 이 자세가
        사이클의 마지막 자세다.
        """
        d = self.d
        # DRL final_drip 하단 설정 — 이 서브루틴부터는 복원하지 않는다(§헤더 참고).
        d.set_velj(FINAL_DRIP_VELJ)
        d.set_accj(FINAL_DRIP_ACCJ)
        d.set_velx(FINAL_DRIP_VELX_LIN, FINAL_DRIP_VELX_ROT)
        d.set_accx(FINAL_DRIP_ACCX_LIN, FINAL_DRIP_ACCX_ROT)

        self._say("FINAL_POUR", "필터 홀더 이동", progress_in_step=0.05,
                  detail={"final_drip_stage": "필터 홀더 이동", "final_drip_progress": 5.0})
        self._movel_rel([0.0, 0.0, -150.0, 0.0, 0.0, 0.0], ref=d.DR_TOOL)
        self._movej(FILTER_HOLDER_J)
        self._movel_abs(FILTER_HOLDER_L)
        self._grip("필터 홀더")
        self._movel_rel([0.0, 0.0, 100.0, 0.0, 0.0, 0.0])
        self._movel_abs(FILTER_HOLDER_PLACE_L)
        self.gripper.open_cup()
        self._movel_rel([0.0, 0.0, -90.0, 0.0, 0.0, 0.0], ref=d.DR_TOOL)
        self._movel_rel([200.0, 0.0, 0.0, 0.0, 0.0, 0.0])

        self._say("FINAL_POUR", "물컵 파지", progress_in_step=0.3,
                  detail={"final_drip_stage": "물컵 파지", "final_drip_progress": 30.0})
        self._movej(MUG_J)
        self._movel_abs(MUG_L)
        self._grip("물컵")
        self._movel_rel([0.0, 0.0, 200.0, 0.0, 0.0, 0.0])
        self._movel_rel([-100.0, 0.0, 0.0, 0.0, 0.0, 0.0])

        self._say("FINAL_POUR", "드립 위치 이동", progress_in_step=0.55,
                  detail={"final_drip_stage": "드립 위치 이동", "final_drip_progress": 55.0})
        d.movej(d.posj(FINAL_POUR_APPROACH_J), time=FINAL_POUR_APPROACH_DURATION_SEC,
                radius=0.0, ra=d.DR_MV_RA_DUPLICATE)
        self._movel_abs(FINAL_POUR_L)
        self._movej(FINAL_POUR_J2)

        self._say("FINAL_POUR", "물 붓기 준비", progress_in_step=0.7,
                  detail={"final_drip_stage": "물 붓기 준비", "final_drip_progress": 70.0})
        if not self.robot.apply_tcp(FINAL_POUR_TCP_NAME):
            raise RuntimeError(f"물 붓기 TCP '{FINAL_POUR_TCP_NAME}' 적용 실패")

        start_pose = self._current_pose_base("현재 mug TCP Base pose")
        start_joint = self._current_joint()
        start_rotation = pm.zyz_to_rotm(start_pose[3:])
        fixed_spout_base = start_pose[:3] + start_rotation @ FINAL_POUR_SPOUT_OFFSET_TOOL_MM

        virtual_final_joint = start_joint.copy()
        virtual_final_joint[5] += FINAL_POUR_J6_DELTA_DEG
        virtual_final_pose = self._forward_kinematics_base(virtual_final_joint)
        final_rotation = pm.zyz_to_rotm(virtual_final_pose[3:])
        relative_rotvec = pm.rotm_to_rotvec(start_rotation.T @ final_rotation)

        numeric_path, path, previous_abc = [], [], start_pose[3:].copy()
        for index in range(1, FINAL_POUR_PATH_POINTS + 1):
            progress_value = pm.smoothstep5(index / float(FINAL_POUR_PATH_POINTS))
            target_rotation = start_rotation @ pm.rotvec_to_rotm(relative_rotvec * progress_value)
            target_abc = pm.rotm_to_zyz_near(target_rotation, previous_abc)
            previous_abc = target_abc
            # 목표 TCP 위치는 "보상된 위치" = 고정 주둥이점 - R*offset (주둥이가
            # target_rotation일 때 TCP가 여기 있어야 주둥이가 그대로 고정된다).
            target_tcp_xyz = fixed_spout_base - target_rotation @ FINAL_POUR_SPOUT_OFFSET_TOOL_MM
            target = np.array([*target_tcp_xyz, *target_abc], dtype=float)
            numeric_path.append(target)
            path.append(d.posx(*[float(v) for v in target]))

        self._validate_movesx_path(start_pose, numeric_path, "final_pour 물 붓기",
                                   FINAL_POUR_MAX_LINEAR_STEP_MM, FINAL_POUR_MAX_ANGULAR_STEP_DEG)

        self._say("FINAL_POUR", "주둥이 위치를 유지하며 물 붓는 중", progress_in_step=0.85,
                  detail={"final_drip_stage": "물 붓기", "final_drip_progress": 85.0,
                          "final_pour_duration_sec": FINAL_POUR_DURATION_SEC,
                          "final_pour_j6_delta_deg": FINAL_POUR_J6_DELTA_DEG})
        self._call_movesx(
            path, FINAL_POUR_DURATION_SEC,
            linear_vel=FINAL_POUR_MOVESX_LINEAR_VEL_MM_S,
            angular_vel=FINAL_POUR_MOVESX_ANGULAR_VEL_DEG_S,
            linear_acc=FINAL_POUR_MOVESX_LINEAR_ACC_MM_S2,
            angular_acc=FINAL_POUR_MOVESX_ANGULAR_ACC_DEG_S2)

        end_pose = self._current_pose_base("물 붓기 후 pose")
        end_rotation = pm.zyz_to_rotm(end_pose[3:])
        measured_spout_base = end_pose[:3] + end_rotation @ FINAL_POUR_SPOUT_OFFSET_TOOL_MM
        spout_error_mm = float(np.linalg.norm(measured_spout_base - fixed_spout_base))
        self.log.info(f"final_pour 주둥이 고정 오차: {spout_error_mm:.3f} mm")
        if spout_error_mm > FINAL_POUR_SPOUT_ERROR_WARN_MM:
            self.log.warning(
                f"주둥이 위치 오차가 {FINAL_POUR_SPOUT_ERROR_WARN_MM:.1f} mm를 초과했습니다"
                f"({spout_error_mm:.3f} mm). mug TCP와 FINAL_POUR_SPOUT_OFFSET_TOOL_MM 확인.")

        self._say("FINAL_POUR", "최종 물 붓기 완료", progress_in_step=1.0,
                  detail={"final_drip_stage": "완료", "final_drip_progress": 100.0,
                          "spout_error_mm": round(spout_error_mm, 3)})

    # ---------- 외력 감지 ----------

    def _read_force_xyz(self):
        d = self.d
        value = d.get_tool_force(d.DR_TOOL)
        if not isinstance(value, (list, tuple)) or len(value) < 3:
            raise RuntimeError(f"get_tool_force() 반환값 이상: {value!r}")
        force = tuple(float(value[i]) for i in range(3))
        if not all(math.isfinite(v) for v in force):
            raise RuntimeError(f"get_tool_force()에 비정상 값: {force!r}")
        return force

    def wait_for_external_force(self, threshold_n=FORCE_TRIGGER_N, on_sample=None):
        """기준 힘 대비 변화량이 threshold_n 이상일 때까지 블로킹. 변화량 반환.

        move_periodic 직후의 잔류 진동·정적 하중을 기준으로 삼지 않도록 잠깐
        안정화한 뒤 평균을 기준값으로 잡는다.
        """
        self._say("WAIT_TAP", f"안정화 {FORCE_SETTLE_SEC:.1f}초", waiting="external force")
        time.sleep(FORCE_SETTLE_SEC)

        samples = []
        for _ in range(FORCE_BASELINE_SAMPLES):
            samples.append(self._read_force_xyz())
            time.sleep(FORCE_SAMPLE_SEC)
        baseline = tuple(sum(s[axis] for s in samples) / len(samples)
                         for axis in range(3))
        self.log.info(
            f"외력 기준값: Fx={baseline[0]:.3f} Fy={baseline[1]:.3f} "
            f"Fz={baseline[2]:.3f} N, threshold={threshold_n:.1f} N")

        consecutive, peak, next_report = 0, 0.0, 0.0
        while rclpy.ok():
            current = self._read_force_xyz()
            delta = [current[i] - baseline[i] for i in range(3)]
            delta_norm = math.sqrt(sum(v * v for v in delta))
            peak = max(peak, delta_norm)

            if on_sample is not None:
                on_sample(delta_norm, peak)
            now = time.monotonic()
            if now >= next_report:
                self._say("WAIT_TAP",
                          f"병 바닥을 쳐주세요 — 현재 {delta_norm:.1f} N / "
                          f"{threshold_n:.1f} N", waiting="external force",
                          detail={"force_delta_n": round(delta_norm, 3),
                                  "force_peak_n": round(peak, 3),
                                  "force_threshold_n": threshold_n})
                next_report = now + FORCE_REPORT_SEC

            if delta_norm >= threshold_n:
                consecutive += 1
                if consecutive >= FORCE_CONFIRM_SAMPLES:
                    self.log.info(f"외력 감지: {delta_norm:.3f} N (peak={peak:.3f} N)")
                    return delta_norm
            else:
                consecutive = 0
            time.sleep(FORCE_SAMPLE_SEC)

        raise KeyboardInterrupt
