# =============================================================
# gripper.py — OnRobot RG2 명령 + 파지 판정 (두 모듈이 공유하는 단일 창구)
# -------------------------------------------------------------
# 실행: 라이브러리
# 의존: rclpy, std_msgs, sensor_msgs, (service 채널일 때) onrobot_rg_msgs
# -------------------------------------------------------------
# 통합 포인트: 명령 경로와 모니터링 경로가 다르다 (docs/GRIP_DETECTION.md §1).
#   · 명령: 컨트롤박스 DO 1/2 접점 조합(커피 시스템) 또는
#           /onrobot/sendCommand 서비스(probe_grip). 한 실행에서 섞지 말 것.
#   · 판정: onrobot_rg_control 노드가 Modbus로 읽어 발행하는 토픽
#           /onrobot/grip_detected(Bool), /onrobot_joint_states(JointState).
#     -> DO로 닫아도 판정을 하려면 onrobot_rg_control이 반드시 떠 있어야 한다.
#
# DO 접점 조합 = 컴퓨트박스/웹UI에 미리 저장된 폭·힘 프리셋 선택이다. 코드에서
# 폭이나 힘을 지정하는 게 아니다 — 종이컵용 저힘 프리셋이 필요하면 컴퓨트박스
# 쪽에서 바꿔야 한다 (docs/GRIP_DETECTION.md §6).
#
# 판정 우선순위: 하드웨어 grip 비트 > effort(gSTA 비0) > position 갭.
#   실측(force=40N): 빈손 정착 position 0.7587 / effort 0.0,
#                    얇은 강체    position 0.7141 / effort 40.0  (갭 ≈0.045 rad)
# =============================================================

import time

import rclpy
from sensor_msgs.msg import JointState
from std_msgs.msg import Bool

GRIPPER_SERVICE = "/onrobot/sendCommand"
GRIP_BIT_TOPIC = "/onrobot/grip_detected"
GRIPPER_JS_TOPIC = "/onrobot_joint_states"

# (DO1, DO2) -> 컴퓨트박스 프리셋. 주석의 width/force는 실기 설정값 기준.
DO_CLOSE = (1, 0)        # width 5mm,   Force 40N — 파지
DO_OPEN_JAR = (0, 1)     # width 70mm,  Force 40N — 병/손잡이 놓기
DO_OPEN_WIDE = (1, 1)    # width 104mm(max)      — 최대 개방
DO_OPEN_CUP = (0, 0)     # width 35mm            — 스푼/컵

# 파지 판정 튜닝값 (실측 교정 대상 — README §튜닝 표)
POS_CLOSED_EMPTY = 0.7587   # rad, 빈손으로 끝까지 닫혔을 때의 position
POS_MARGIN = 0.02           # rad
VERIFY_TIMEOUT_S = 3.0
GRIP_SETTLE_S = 1.5         # 닫기 명령 후 기구가 정착할 때까지 (판정 전 대기)


class GripFailed(RuntimeError):
    """파지 판정 실패. 놓친 채 이동하면 낙하하므로 플로우가 반드시 잡을 것."""


class Gripper:
    """RG2 개폐 + 파지 판정. channel로 명령 경로를 고른다."""

    def __init__(self, robot, channel="digital_output",
                 pos_closed_empty=POS_CLOSED_EMPTY, pos_margin=POS_MARGIN,
                 verify_timeout_s=VERIFY_TIMEOUT_S, settle_s=GRIP_SETTLE_S):
        if channel not in ("digital_output", "service"):
            raise ValueError("channel은 'digital_output' 또는 'service'")
        self.robot = robot
        self.node = robot.node
        self.log = robot.log
        self.channel = channel
        self.pos_closed_empty = pos_closed_empty
        self.pos_margin = pos_margin
        self.verify_timeout_s = verify_timeout_s
        self.settle_s = settle_s
        self._service_client = None
        if channel == "service":
            from onrobot_rg_msgs.srv import SetCommand

            self._set_command = SetCommand
            self._service_client = self.node.create_client(SetCommand, GRIPPER_SERVICE)
            if not self._service_client.wait_for_service(timeout_sec=5.0):
                raise RuntimeError(
                    f"그리퍼 서비스 {GRIPPER_SERVICE} 없음 — onrobot_rg_control 확인")

    # ---------- 명령 ----------

    def _do(self, combo, label):
        d = self.robot.dsr
        on, off = getattr(d, "ON", 1), getattr(d, "OFF", 0)
        do1, do2 = combo
        self.log.info(f"Gripper[DO] {label}: DO1={do1} DO2={do2}")
        d.set_digital_output(1, on if do1 else off)
        d.set_digital_output(2, on if do2 else off)

    def _service(self, command, label):
        self.log.info(f"Gripper[SVC] {label}: '{command}'")
        request = self._set_command.Request()
        request.command = command
        future = self._service_client.call_async(request)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=3.0)
        result = future.result() if future.done() else None
        if result is None or not result.success:
            message = result.message if result is not None else "no response"
            raise RuntimeError(f"그리퍼 명령 '{command}' 실패: {message}")

    def close(self):
        if self.channel == "service":
            self._service("c", "close")
        else:
            self._do(DO_CLOSE, "close")

    def open(self, preset=DO_OPEN_WIDE, label="open"):
        """service 채널에서는 preset을 무시하고 'o'(웹UI 설정 폭)로 연다."""
        if self.channel == "service":
            self._service("o", label)
        else:
            self._do(preset, label)

    def open_jar(self):
        self.open(DO_OPEN_JAR, "open(jar 70mm)")

    def open_wide(self):
        self.open(DO_OPEN_WIDE, "open(max 104mm)")

    def open_cup(self):
        self.open(DO_OPEN_CUP, "open(spoon/cup 35mm)")

    # ---------- 판정 ----------

    def verify_grip(self, timeout_sec=None):
        """close() 직후 파지 여부. 반환 (held: bool, reason: str).

        ponytail: 호출할 때마다 구독을 만들고 지운다. 이 파이프라인은 블로킹
        절차형이라 상시 콜백이 돌지 않기 때문. 나중에 executor로 상시 spin
        하도록 바꾸면 최신값 캐싱 구독으로 승격할 것.
        """
        timeout_sec = self.verify_timeout_s if timeout_sec is None else timeout_sec
        latest = {"grip": None, "eff": None, "pos": None}

        def on_bit(msg):
            latest["grip"] = msg.data

        def on_js(msg):
            if msg.position:
                latest["pos"] = msg.position[0]
            if msg.effort:
                latest["eff"] = msg.effort[0]

        sub_bit = self.node.create_subscription(Bool, GRIP_BIT_TOPIC, on_bit, 3)
        sub_js = self.node.create_subscription(JointState, GRIPPER_JS_TOPIC, on_js, 3)
        try:
            deadline = time.monotonic() + timeout_sec
            while latest["grip"] is None and time.monotonic() < deadline:
                rclpy.spin_once(self.node, timeout_sec=0.05)
        finally:
            self.node.destroy_subscription(sub_bit)
            self.node.destroy_subscription(sub_js)

        if latest["grip"] is not None:
            return bool(latest["grip"]), f"hardware grip bit={latest['grip']}"
        if latest["eff"] is not None:
            return latest["eff"] != 0.0, f"effort={latest['eff']:.2f} (nonzero=grip)"
        if latest["pos"] is not None:
            held = latest["pos"] < (self.pos_closed_empty - self.pos_margin)
            return held, (f"position={latest['pos']:.4f} vs empty="
                          f"{self.pos_closed_empty:.4f} (margin {self.pos_margin})")
        return False, "그리퍼 상태 토픽 없음 (onrobot_rg_control 미기동?)"

    def close_and_verify(self, what="object", settle_s=None):
        """닫고 정착을 기다린 뒤 판정. (held, reason).

        실패했을 때 무엇을 할지(재시도/중단/알림)는 호출자 = 플로우의 결정이다.
        여기서 예외를 던지지 않는다 — 놓친 걸 알고도 그냥 이동하면 낙하 위험이
        있으니 호출자가 반드시 반환값을 보고 분기할 것.
        """
        self.close()
        time.sleep(self.settle_s if settle_s is None else settle_s)
        held, reason = self.verify_grip()
        # 한 줄에서 info/warning을 골라 부르면 안 된다. rclpy는 호출 지점
        # (파일·줄·함수)마다 severity를 캐시해 두고, 같은 줄에서 다른 severity로
        # 다시 부르면 ValueError("Logger severity cannot be changed between
        # calls.")를 던진다 — 첫 파지는 성공(INFO), 다음 파지는 실패(WARN)인
        # 순간 공정이 통째로 죽었던 실측 버그다. 분기마다 줄을 따로 준다.
        message = f"grip verify [{what}]: held={held} ({reason})"
        if held:
            self.log.info(message)
        else:
            self.log.warning(message)
        return held, reason
