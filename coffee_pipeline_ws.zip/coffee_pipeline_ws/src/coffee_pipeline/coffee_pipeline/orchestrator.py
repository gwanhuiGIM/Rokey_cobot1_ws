# =============================================================
# orchestrator.py — 통합 플로우 (여기가 당신이 손댈 파일이다)
# -------------------------------------------------------------
# 실행: ros2 run coffee_pipeline orchestrator --ros-args -p arm:=true
#       (arm:=true 없이는 로봇에 아무 명령도 나가지 않는다 — 실기 안전)
# 노드: /dsr01/coffee_pipeline — 이 프로세스가 DSR 모션 노드의 '유일한' 주인
# 발행: /coffee_process/state (process_state 규약) -> system_monitor가 구독
# -------------------------------------------------------------
# 구조
#   Robot        : DSR 세션 1개 (모션 API + 정지 + TCP 전환)
#   Gripper      : RG2 명령 + 파지 판정
#   CoffeeSteps  : bean_drop / grinder / transfer_grounds / hand_drip / final_pour
#   ProcessReporter : 모니터·웹UI로 진행 보고
#
# 공정은 5단계 전체가 이어붙었다 (2026-07-28, src/rokey/rokey/coffee_system.py
# 최신본 반영 — 이전엔 1~3단계만 있었고, "4~6단계"로 컵 서빙을 추측했던
# docs/plans/2026-07-27-full-6-stage-flow.md 예약표는 틀렸다. 실제 마지막
# 두 단계는 서빙이 아니라 핸드드립·최종 붓기다):
#   1) 원두      스푼 파지 -> 그라인더 호퍼 투입           steps.bean_drop()
#   2) 그라인딩   손잡이 파지 -> 선택 회전수만큼 분쇄        steps.grinder(n)
#   3) 운반      병 파지 -> 이송/붓기 -> 힘제어 외력 감지    steps.transfer_grounds()
#   4) 핸드드립   주전자 파지 -> 위치보상 내향 스파이럴 붓기  steps.hand_drip()
#   5) 최종 붓기  필터홀더+물컵 배치 -> 위치보상 붓기         steps.final_pour()
#      (final_pour는 시작 자세로 복귀하지 않는다 — 사이클의 마지막 자세)
# 컵 접촉 탐지(probe_grip)는 이 공정과 무관한 별개 모듈이다 — 단독 실행으로만 돌린다:
#   ros2 run coffee_pipeline probe_grip --ros-args -p arm:=true
#
# 단계 실패 처리 (2026-07-27 확정): 예외가 나면 노드를 죽이지 않는다.
# run_stage()가 정지 -> 사람에게 알리고 DI13(재시도)/DI16(중단) 대기 -> 재시도는
# steps.home()부터 다시 시작한다. 재시도 전 현장(그리퍼에 든 물건, 흘린 원두)
# 정리는 사람 책임 — 로봇은 자기가 뭘 들고 있었는지 모르므로 자동 복구는 하지 않는다.
# (final_pour는 완료 시 홈으로 복귀하지 않으므로 재시도해도 steps.home()부터
#  다시 감 — 4~5단계 실패 후 재시도가 1~3단계를 다시 도는 게 맞는지는 README
#  §미검증 참고.)
#
# 남은 결정(TODO 플로우):
#   1. 사이클 반복 / 중단 요청(외부 토픽) 처리
#   2. 재시도 최대 횟수를 둘지 (지금은 사람이 버튼을 누르는 구조라 무한 대기만 있음)
# =============================================================

import time

import rclpy

from coffee_pipeline.buttons import (
    ABORT_BUTTON, BEAN_BY_BUTTON, GRIND_BY_BUTTON, PhysicalButtonInput, RETRY_BUTTON,
)
from coffee_pipeline.coffee_steps import CoffeeSteps
from coffee_pipeline.gripper import Gripper
from coffee_pipeline.process_state import STEP, ProcessReporter
from coffee_pipeline.robot import Robot, create_node

NODE_NAME = "coffee_pipeline"


def declare_params(node):
    p = node.declare_parameter
    p("arm", False)                     # 실기 모션 장전 스위치
    p("gripper_channel", "digital_output")   # digital_output | service
    p("verify_grip", True)              # 파지 판정 on/off
    return lambda name: node.get_parameter(name).value


def wait_selection(node, buttons, report, step, table, prompt):
    """물리 버튼 1개를 기다려 table의 선택지를 돌려준다.

    detail에 selected_*을 실어 웹UI 고객 화면(원두/분쇄 카드 강조)이 어떤
    버튼이 눌렸는지 알 수 있게 한다 — web_ui.py의 STEP_TO_SCREEN 참고.
    """
    report.set(step, prompt, waiting="DI13~16")
    button = buttons.wait_for_button()
    choice = table[button]
    node.get_logger().info(f"DI {button} -> {choice['name']}")
    if step == STEP.SELECT_BEAN:
        detail = {"selected_bean": choice["name"], "selected_button": button}
    else:
        detail = {"selected_grind": choice["name"], "selected_grind_button": button,
                  "grind_turns": choice.get("turns", 0)}
    report.set(step, f"{choice['name']} 선택", detail=detail)
    return button, choice


def run_stage(name, fn, node, robot, steps, buttons, report):
    """1개 공정 단계 실행 + 실패 시 사람 개입 재시도 루프.

    실패(GripFailed 등 어떤 예외든) -> 정지 -> report.error로 재시도/중단
    버튼을 안내 -> 대기. RETRY_BUTTON(DI13)=재시도(steps.home()부터 다시),
    ABORT_BUTTON(DI16)=중단(예외를 그대로 올려 main()의 핸들러로).
    현장(그리퍼에 든 물건, 흘린 원두) 정리는 사람 책임 — 로봇은 실패 시점에
    뭘 들고 있었는지 모르므로 여기서 자동으로 열거나 되돌리지 않는다.

    FINAL_POUR가 실패하면 그 시점엔 이미 FINAL_DRIP_* 고속 프로파일이
    적용돼 있다(final_pour()는 복원하지 않음 — coffee_steps.py 헤더 참고).
    그 상태로 steps.home()을 돌리면 평소보다 빠르게 움직이므로, 재시도 직전
    항상 기본 속도로 되돌린다.
    """
    while True:
        t0 = time.monotonic()
        try:
            result = fn()
            elapsed = round(time.monotonic() - t0, 1)
            node.get_logger().info(f"[{name}] {elapsed}s")
            return result, elapsed
        except KeyboardInterrupt:
            raise
        except Exception as error:
            node.get_logger().error(f"[{name}] 실패: {error}")
            report.error(
                f"{name} 실패: {error} "
                f"(현장 정리 후 DI{RETRY_BUTTON}=재시도 DI{ABORT_BUTTON}=중단)")
            _safe_stop(node, robot)
            if buttons.wait_for_button() == ABORT_BUTTON:
                raise
            robot.apply_motion_defaults()   # FINAL_POUR 실패 대비 (위 설명 참고)
            steps.home()


def run_cycle(node, robot, steps, buttons, report):
    """확정 3단계 1 사이클. 각 단계는 run_stage로 감싸 재시도 가능."""
    report.set(STEP.INIT, "Tool/TCP 설정")
    robot.apply_motion_defaults()
    robot.set_tool_tcp()

    steps.home()

    # --- 1단계: 원두 (스푼 파지 -> 그라인더 투입) ---
    _, bean = wait_selection(node, buttons, report, STEP.SELECT_BEAN,
                             BEAN_BY_BUTTON, "원두를 선택하세요 (DI 13~16)")
    _, t_bean = run_stage("BEAN_DROP", steps.bean_drop, node, robot, steps, buttons, report)

    # --- 2단계: 그라인딩 (손잡이 파지 -> 회전 분쇄) ---
    _, grind = wait_selection(node, buttons, report, STEP.SELECT_GRIND,
                              GRIND_BY_BUTTON, "분쇄 굵기를 선택하세요 (DI 13~16)")
    _, t_grind = run_stage("GRINDING", lambda: steps.grinder(int(grind["turns"])),
                           node, robot, steps, buttons, report)

    # --- 3단계: 갈린 원두 운반 (병 파지 -> 이송/붓기 -> 외력 감지 -> 복귀) ---
    detected_n, t_bottle = run_stage("BOTTLE_MOVE", steps.transfer_grounds,
                                     node, robot, steps, buttons, report)

    # --- 4단계: 핸드드립 (주전자 파지 -> 내향 스파이럴 붓기 -> 반환) ---
    _, t_hand_drip = run_stage("HAND_DRIP", steps.hand_drip,
                               node, robot, steps, buttons, report)

    # --- 5단계: 최종 붓기 (필터홀더+물컵 배치 -> 위치보상 붓기) ---
    # 완료 후 시작 자세로 복귀하지 않는다 — 사이클의 마지막 자세.
    _, t_final_pour = run_stage("FINAL_POUR", steps.final_pour,
                                node, robot, steps, buttons, report)

    timing = {
        "BEAN_DROP": t_bean, "GRINDING": t_grind, "BOTTLE_MOVE": t_bottle,
        "HAND_DRIP": t_hand_drip, "FINAL_POUR": t_final_pour,
    }
    report.set(STEP.DONE, f"완료 (외력 {detected_n:.1f} N 확인, 단계별 소요 {timing} s)")
    return {"bean": bean["id"], "grind": grind["id"], "tap_force_n": detected_n, "timing": timing}


def main(args=None):
    rclpy.init(args=args)
    node = create_node(NODE_NAME)
    get = declare_params(node)
    report = ProcessReporter(node)

    if not bool(get("arm")):
        node.get_logger().error(
            "로봇 미장전(arm=false) — 모션을 내보내지 않는다. "
            "실기 실행은 사람 감독 하에 -p arm:=true 로.")
        node.destroy_node()
        rclpy.shutdown()
        return

    robot = Robot.connect(node)
    gripper = Gripper(robot, channel=str(get("gripper_channel")))
    steps = CoffeeSteps(robot, gripper, report, verify_grip=bool(get("verify_grip")))
    buttons = PhysicalButtonInput(node, robot.dsr.get_digital_input)

    try:
        summary = run_cycle(node, robot, steps, buttons, report)
        node.get_logger().info(f"사이클 완료: {summary}")
        # TODO(플로우 2): 여기서 while로 감아 사이클 반복 / 중단 요청 수신.

    except KeyboardInterrupt:
        node.get_logger().warning("사용자 중단(Ctrl-C) — 모션 정지")
        report.error("사용자 중단")
        _safe_stop(node, robot)

    except Exception as error:
        # 단계 내 실패(GripFailed 등)는 run_stage가 먼저 잡아 재시도/중단을
        # 물어본다 — 여기까지 올라온 건 사람이 ABORT_BUTTON으로 중단을 택한 경우다.
        node.get_logger().error(f"실행 중 오류: {type(error).__name__}: {error}")
        report.error(f"{type(error).__name__}: {error}")
        _safe_stop(node, robot)
        raise
        # 정지 후 자동 홈 복귀는 하지 않는다 — 장애물 상황을 모르는 채 움직이면 위험.

    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


def _safe_stop(node, robot):
    try:
        robot.dsr.release_compliance_ctrl()
    except Exception as error:
        node.get_logger().warning(f"release_compliance_ctrl 실패(무시): {error}")
    try:
        robot.stop()
    except Exception as error:
        node.get_logger().error(f"move_stop 실패: {error}")


if __name__ == "__main__":
    main()
