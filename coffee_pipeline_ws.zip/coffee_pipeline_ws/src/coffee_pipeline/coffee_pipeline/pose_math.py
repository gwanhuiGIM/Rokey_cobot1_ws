# =============================================================
# pose_math.py — ZYZ 오일러 <-> 회전벡터/행렬 변환, movesx 경로 생성 수학
# -------------------------------------------------------------
# 실행: 라이브러리 (자체 점검: python3 -m coffee_pipeline.pose_math --selftest)
# 의존: numpy만 — rclpy/DSR SDK 몰라도 되게 일부러 분리했다 (web_ui 등
#   비-모션 프로세스에서도 import 가능, 로봇 없는 PC에서 단위 테스트 가능).
# -------------------------------------------------------------
# 원본: src/rokey/rokey/coffee_system.py 의 "스파이럴 자세/경로 수학 유틸리티"
# 절(원본 함수명 앞 밑줄 제거만 하고 로직은 그대로 옮김) — coffee_steps.py의
# hand_drip()/final_pour()가 이 모듈로 원호/나선 경로를 만든다.
#
# 좌표계 주의 (CLAUDE.md 이전 세션 메모와 다른 케이스):
#   여기서 다루는 ABC는 DR_BASE 기준 **절대 자세**의 Doosan Z-Y-Z 오일러다
#   (movesx 절대 경로 생성용). "movel REL+TOOL 자세 = 회전벡터"였던 실기
#   검증 메모는 상대(REL) 델타 얘기라 여기(절대 ABS, movesx)와는 별개다.
#
# 핵심 함수
# - zyz_to_rotm / rotm_to_zyz_near : ABC(deg) <-> 3x3 회전행렬. near는 이전
#   자세에 가장 가까운 해를 골라(짐벌락 근처에서도) 오일러각이 안 튀게 한다.
# - rotvec_to_rotm / rotm_to_rotvec : 회전벡터(축*각도, rad) <-> 행렬.
#   두 자세 사이 "최단 회전"을 보간할 때 회전벡터 스케일링을 쓴다.
# - smoothstep5 : 5차 smoothstep(0,0 -> 1,1, 양끝 기울기 0) — 각도 보간에
#   써서 시작/끝에서 급가속 없이 부드럽게 돈다.
# =============================================================

import math

import numpy as np


def clamp(value, low, high):
    return max(low, min(high, float(value)))


def smoothstep5(progress):
    """5차 smoothstep. 0<=u<=1, u=0/1에서 기울기 0 (부드러운 가감속)."""
    u = clamp(progress, 0.0, 1.0)
    return 10.0 * u**3 - 15.0 * u**4 + 6.0 * u**5


def rot_y_deg(angle_deg):
    angle = math.radians(float(angle_deg))
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]], dtype=float)


def rot_z_deg(angle_deg):
    angle = math.radians(float(angle_deg))
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]], dtype=float)


def zyz_to_rotm(abc_deg):
    """Doosan Z-Y-Z 오일러(A,B,C deg, 절대자세) -> 3x3 회전행렬."""
    a_deg, b_deg, c_deg = [float(v) for v in abc_deg[:3]]
    return rot_z_deg(a_deg) @ rot_y_deg(b_deg) @ rot_z_deg(c_deg)


def project_rotation(rotation):
    """SVD로 가장 가까운 정규 회전행렬에 투영(수치오차 누적 방지)."""
    u_matrix, _, vt_matrix = np.linalg.svd(np.asarray(rotation, dtype=float).reshape(3, 3))
    output = u_matrix @ vt_matrix
    if np.linalg.det(output) < 0.0:
        u_matrix[:, -1] *= -1.0
        output = u_matrix @ vt_matrix
    return output


def rotvec_to_rotm(rotvec_rad):
    """회전벡터(축*각도, rad) -> 회전행렬 (Rodrigues)."""
    vector = np.asarray(rotvec_rad, dtype=float).reshape(3)
    angle = float(np.linalg.norm(vector))
    if angle < 1.0e-12:
        return np.eye(3, dtype=float)
    axis = vector / angle
    x, y, z = axis
    skew = np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]], dtype=float)
    return (np.eye(3, dtype=float) + math.sin(angle) * skew
            + (1.0 - math.cos(angle)) * (skew @ skew))


def rotm_to_rotvec(rotation):
    """회전행렬 -> 회전벡터(rad). 짐벌락(angle≈pi) 분기 포함."""
    matrix = project_rotation(rotation)
    cosine_angle = clamp((float(np.trace(matrix)) - 1.0) * 0.5, -1.0, 1.0)
    angle = math.acos(cosine_angle)

    if angle < 1.0e-10:
        return np.zeros(3, dtype=float)

    if abs(math.pi - angle) < 1.0e-6:
        diagonal = np.maximum((np.diag(matrix) + 1.0) * 0.5, 0.0)
        axis = np.sqrt(diagonal)
        if matrix[2, 1] - matrix[1, 2] < 0.0:
            axis[0] *= -1.0
        if matrix[0, 2] - matrix[2, 0] < 0.0:
            axis[1] *= -1.0
        if matrix[1, 0] - matrix[0, 1] < 0.0:
            axis[2] *= -1.0
        axis_norm = float(np.linalg.norm(axis))
        axis = axis / axis_norm if axis_norm >= 1.0e-9 else np.array([1.0, 0.0, 0.0])
        return axis * angle

    factor = angle / (2.0 * math.sin(angle))
    return factor * np.array([
        matrix[2, 1] - matrix[1, 2],
        matrix[0, 2] - matrix[2, 0],
        matrix[1, 0] - matrix[0, 1],
    ], dtype=float)


def wrapped_delta_deg(value, reference):
    return (float(value) - float(reference) + 180.0) % 360.0 - 180.0


def rotm_to_zyz_candidates(rotation):
    """회전행렬 -> Doosan Z-Y-Z 오일러 후보 2개(부호 모호성)."""
    matrix = project_rotation(rotation)
    b_angle = math.acos(clamp(float(matrix[2, 2]), -1.0, 1.0))
    sine_b = math.sin(b_angle)

    if abs(sine_b) > 1.0e-8:
        a_angle = math.atan2(float(matrix[1, 2]), float(matrix[0, 2]))
        c_angle = math.atan2(float(matrix[2, 1]), -float(matrix[2, 0]))
        first = np.degrees(np.array([a_angle, b_angle, c_angle], dtype=float))
        second = np.array([first[0] + 180.0, -first[1], first[2] + 180.0], dtype=float)
        return [first, second]

    combined = math.degrees(math.atan2(float(matrix[1, 0]), float(matrix[0, 0])))
    b_deg = math.degrees(b_angle)
    return [np.array([combined, b_deg, 0.0], dtype=float),
            np.array([0.0, b_deg, combined], dtype=float)]


def rotm_to_zyz_near(rotation, reference_abc_deg):
    """회전행렬 -> 이전 자세(reference)에 가장 가까운 Z-Y-Z 오일러 해.

    두 후보(부호 모호성) 중 reference와의 각도차가 작은 쪽을 고르고, A/C는
    360도 랩어라운드를 풀어(reference 기준 최단 델타) 프레임 간 오일러각이
    갑자기 튀지 않게 한다 — movesx 경로점 생성에 필수(안 그러면 웨이포인트
    사이가 실제로는 작은 회전인데 오일러각으로는 거의 360도 점프해 보인다).
    """
    reference = np.asarray(reference_abc_deg, dtype=float).reshape(3)
    best, best_cost = None, math.inf

    for candidate in rotm_to_zyz_candidates(rotation):
        adjusted = candidate.copy()
        for index in (0, 2):
            adjusted[index] = reference[index] + wrapped_delta_deg(
                adjusted[index], reference[index])
        cost = float(np.linalg.norm(np.array([
            wrapped_delta_deg(adjusted[0], reference[0]),
            adjusted[1] - reference[1],
            wrapped_delta_deg(adjusted[2], reference[2]),
        ], dtype=float)))
        if cost < best_cost:
            best, best_cost = adjusted, cost

    if best is None:
        raise RuntimeError("회전행렬을 Doosan Z-Y-Z Euler로 변환하지 못했습니다.")
    return best


def numeric6(value, *, label):
    """get_current_posx()/get_current_posj()/fkin() 반환값 -> 6원소 ndarray.

    DSR_ROBOT2 버전에 따라 값 자체 또는 (값, solution_space) 튜플로 올 수
    있어 두 형식을 모두 받는다.
    """
    candidate = value
    if isinstance(candidate, tuple) and len(candidate) >= 1:
        first = candidate[0]
        if hasattr(first, "__iter__") and not isinstance(first, (str, bytes)):
            candidate = first
    elif isinstance(candidate, list) and len(candidate) == 2:
        first = candidate[0]
        if hasattr(first, "__iter__") and not isinstance(first, (str, bytes)):
            first_values = list(first)
            if len(first_values) >= 6:
                candidate = first_values

    try:
        values = np.asarray([float(item) for item in candidate], dtype=float)
    except Exception as exc:
        raise RuntimeError(f"{label} 변환 실패: {value!r}") from exc

    if values.size < 6:
        raise RuntimeError(f"{label} 길이 오류: {values.tolist()!r}")
    result = values[:6].copy()
    if not np.all(np.isfinite(result)):
        raise RuntimeError(f"{label}에 유효하지 않은 값이 있습니다: {result!r}")
    return result


def rotation_distance_deg(first_abc, second_abc):
    """두 절대자세(ABC, deg) 사이의 최단 회전각(deg)."""
    relative = rotm_to_rotvec(zyz_to_rotm(first_abc).T @ zyz_to_rotm(second_abc))
    return math.degrees(float(np.linalg.norm(relative)))


def _demo():
    identity_abc = np.array([10.0, 20.0, 30.0])
    matrix = zyz_to_rotm(identity_abc)
    assert np.allclose(matrix @ matrix.T, np.eye(3), atol=1e-9)      # 정규직교
    assert abs(np.linalg.det(matrix) - 1.0) < 1e-9                   # 우수 좌표계

    recovered = rotm_to_zyz_near(matrix, identity_abc)
    assert np.allclose(zyz_to_rotm(recovered), matrix, atol=1e-6)

    # 회전벡터 왕복
    rotvec = np.array([0.1, -0.2, 0.3])
    assert np.allclose(rotm_to_rotvec(rotvec_to_rotm(rotvec)), rotvec, atol=1e-9)
    assert np.allclose(rotvec_to_rotm(np.zeros(3)), np.eye(3))

    assert abs(smoothstep5(0.0)) < 1e-12
    assert abs(smoothstep5(1.0) - 1.0) < 1e-12
    assert smoothstep5(-1.0) == smoothstep5(0.0)   # 클램프

    # 두 자세 사이 최단 회전각: Z만 90도 돌린 경우 90이어야 한다
    a = np.array([0.0, 0.0, 0.0])
    b = np.array([90.0, 0.0, 0.0])
    assert abs(rotation_distance_deg(a, b) - 90.0) < 1e-6

    assert numeric6([1, 2, 3, 4, 5, 6], label="t").tolist() == [1, 2, 3, 4, 5, 6]
    assert numeric6(([1, 2, 3, 4, 5, 6], 0), label="t").tolist() == [1, 2, 3, 4, 5, 6]
    print("pose_math self-check OK")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--selftest":
        _demo()
