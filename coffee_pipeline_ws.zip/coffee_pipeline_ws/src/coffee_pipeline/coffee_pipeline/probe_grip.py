# =============================================================
# probe_grip.py — X-직진 접촉 탐지 + 측면 파지 (컵 집기)
# -------------------------------------------------------------
# ⚠ 2026-07-27: 커피 공정(3단계)에서 **분리**했다. orchestrator는 이 모듈을
#   부르지 않는다. 공정 상태(/coffee_process/state)에도 CUP_* 스텝이 없다.
#   다시 합칠 때: process_state.STEPS에 CUP_* 추가 -> say()를 report.set으로
#   되돌리고 -> orchestrator에서 run_once(ctx) 호출.
# 실행(단독): ros2 run coffee_pipeline probe_grip --ros-args -p arm:=true
# 통합 호출: run_once(ProbeGripContext(robot=..., gripper=..., ...)) -> dict
# 좌표계: DR_BASE, 포즈 6D = [x, y, z(mm), A, B, C(deg)]
# -------------------------------------------------------------
# 원본: src/cup_detect/cup_detect/probe_grip_v2.py
# 통합 시 바뀐 것
#  1. 자기 노드/자기 그리퍼 채널을 만들지 않는다 — robot.Robot + gripper.Gripper를
#     받는다. (DSR_ROBOT2는 전역 노드 하나를 공유하므로 한 프로세스에 DSR 모션
#     노드는 하나여야 한다.)
#  2. TCP 전환을 tcp/set_current_tcp 서비스 직접 호출 -> robot.apply_tcp()로 통일.
#     AUTO 모드에서 set_tcp 서비스는 컨트롤러가 거부한 실측 사례가 있다
#     (robot.py 헤더 참고) — 원본 probe 코드는 "이미 원하는 TCP였다"라서
#     그 경로를 안 밟았을 가능성이 크다. README §통합 결정 2번.
#  3. 파지 판정 로직 -> gripper.verify_grip() 공유 (커피 쪽과 같은 판정 기준).
#  4. 진행 상태는 로그로만 남긴다(공정 상태머신과 분리).
#
# 흐름: 안전 관절자세 → 그리퍼 닫기 → 감지 준비위치 → +X 직진 접촉 탐지 →
#   X로 물체반경 후퇴 → 그리퍼 열기 → +Y standoff → -Y 진입(Z유지) →
#   닫기(그립) → 파지 판정 → +Z 상승 → 경유점 → place 위치 → 놓기.
# 안전: detect_enabled=False면 힘 탐지 없이 sim_probe_x_mm 고정 전진(드라이런).
# =============================================================

import time
from dataclasses import dataclass, field
from typing import Optional

import rclpy
from dsr_msgs2.srv import (
    CheckMotion,
    GetCurrentPosx,
    GetToolForce,
    MoveLine,
    MoveStop,
)


@dataclass
class ProbeGripContext:
    """run_once()에 넘기는 실행 컨텍스트.

    [입력 — 물체 1개를 잡기 위해 호출자가 정해줘야 하는 값]
      detection_ready_xyz : +X 직진 탐지를 시작할 준비 위치 [x,y,z]
      grasp_orientation   : 감지·파지 공통 손목 자세 [A,B,C]
      object_radius_mm    : 접촉면 -> 파지중심 X 후퇴량
      grasp_y_standoff_mm / grasp_y_offset_mm : +Y 안전진입 / 최종 Y
      place_via_pose / place_pose : 상승 후 경유점, 내려놓을 위치
    [출력] run_once() 반환 dict:
      {"found", "grip_ok", "reason", "contact_pose", "grasp_pose", "final_pose"}
    """
    robot: object
    gripper: object
    detection_ready_xyz: list
    grasp_orientation: list
    approach_joint: list = field(
        default_factory=lambda: [0.0, 0.0, 90.0, 90.0, -90.0, 0.0])
    speed_mm_s: float = 40.0
    acc_mm_s2: float = 40.0
    joint_speed_deg_s: float = 30.0
    joint_acc_deg_s2: float = 30.0
    detect_enabled: bool = True
    sim_probe_x_mm: float = 150.0
    probe_x_depth_mm: float = 200.0
    contact_force_n: float = 8.5
    contact_force_dir: float = -1.0  # +X 접근 반력은 -X → -1. 부호 뒤집으려면 +1.
    poll_period_s: float = 0.02
    settle_time_s: float = 0.6
    stiffness: list = field(
        default_factory=lambda: [200.0, 3000.0, 3000.0, 200.0, 200.0, 200.0]
    )  # X를 약하게: 접촉을 부드럽게, 부호 감지는 유지
    object_radius_mm: float = 45.0
    grasp_y_standoff_mm: float = 100.0
    grasp_y_offset_mm: float = 15.0
    grasp_z_above_center_mm: float = 0.0
    retreat_z_mm: float = 100.0
    place_via_pose: list = field(
        default_factory=lambda: [779.0, -352.0, 400.0, 148.0, -90.0, -90.0])
    place_pose: list = field(
        default_factory=lambda: [740.0, -600.0, 165.0, 125.0, -90.0, -90.0])
    close_gripper_on_start: bool = True
    verify_grip: bool = True
    tcp_name: Optional[str] = None   # None이면 현재 TCP 유지


def call_service(node, client, request, service_name, timeout_sec=3.0):
    """유한 타임아웃으로 ROS 서비스를 호출."""
    future = client.call_async(request)
    rclpy.spin_until_future_complete(node, future, timeout_sec=timeout_sec)
    if not future.done() or future.result() is None:
        raise RuntimeError(f"{service_name} service timed out")
    return future.result()


def run_once(ctx: ProbeGripContext) -> dict:
    """물체 1개에 대한 탐지 → 파지 → 이송 1회. 결과 dict 반환.

    예외는 호출자에게 전파한다(모션 중이면 이미 정지 시도됨).
    """
    robot, gripper = ctx.robot, ctx.gripper
    node, d = robot.node, robot.dsr
    logger = robot.log
    result = {
        "found": False, "grip_ok": False, "reason": "",
        "contact_pose": None, "grasp_pose": None, "final_pose": None,
    }

    def say(phase, message="", progress_in_step=None):
        # 커피 공정(process_state)과 분리됨 — 여기 phase는 로그 태그일 뿐이고
        # /coffee_process/state 스텝이 아니다. 나중에 공정에 다시 합칠 때
        # STEPS에 CUP_* 를 추가하고 report로 되돌린다.
        logger.info(f"[{phase}] {message}"
                    + (f" ({progress_in_step:.0%})" if progress_in_step else ""))

    # -- 서비스 사전 discovery (DSR wrapper의 Fast DDS race 회피) --------------
    for service_type, service_name in (
        (GetCurrentPosx, "aux_control/get_current_posx"),
        (GetToolForce, "aux_control/get_tool_force"),
        (MoveLine, "motion/move_line"),
        (MoveStop, "motion/move_stop"),
        (CheckMotion, "motion/check_motion"),
    ):
        client = node.create_client(service_type, service_name)
        if not client.wait_for_service(timeout_sec=5.0):
            raise RuntimeError(f"필수 서비스 없음: {service_name}")
        node.destroy_client(client)
    logger.info("probe_grip: 필수 서비스 준비 완료")

    if ctx.tcp_name and d.get_tcp() != ctx.tcp_name:
        if not robot.apply_tcp(ctx.tcp_name):
            raise RuntimeError(f"TCP '{ctx.tcp_name}' 활성화 실패")

    # Tool payload가 없으면 외력 추정이 편향돼 X 접촉 탐지가 신뢰할 수 없다.
    if not d.get_tool():
        logger.warning("Tool payload 프리셋이 비어 있음 — 외력 기반 접촉 탐지 부정확")

    fsm = {"motion_active": False, "compliance_active": False}
    speed, acceleration = ctx.speed_mm_s, ctx.acc_mm_s2

    def move_line(pose, label):
        logger.info(f"[move_line] {label}: {pose}")
        if d.movel(d.posx(pose), vel=[speed, 50.0], acc=[acceleration, 10.0],
                   ref=d.DR_BASE, mod=d.DR_MV_MOD_ABS) != 0:
            raise RuntimeError(f"{label}: movel rejected")

    def move_joint(joint_deg, label):
        logger.info(f"[move_joint] {label}: {joint_deg}")
        if d.movej(d.posj(joint_deg), vel=ctx.joint_speed_deg_s,
                   acc=ctx.joint_acc_deg_s2) != 0:
            raise RuntimeError(f"{label}: movej rejected")

    def read_tool_force_x():
        force = d.get_tool_force(ref=d.DR_BASE)
        if force == -1 or len(force) < 1:
            return None
        return float(force[0])

    def probe_forward_x(from_pose, label):
        """from_pose에서 Base +X로 전진, X 반력 접촉 시 급정지.

        반환: "contact" | "reached_depth". 컴플라이언스는 호출 전 진입돼 있어야 함.
        """
        target = list(from_pose)
        target[0] += ctx.probe_x_depth_mm
        if d.amovel(d.posx(target), vel=[speed, 50.0], acc=[acceleration, 10.0],
                    ref=d.DR_BASE, mod=d.DR_MV_MOD_ABS) != 0:
            raise RuntimeError(f"{label}: amovel(probe) rejected")
        fsm["motion_active"] = True

        motion_seen, peak_fx, last_diag, outcome = False, 0.0, 0.0, None
        move_start = time.monotonic()
        deadline = move_start + ctx.probe_x_depth_mm / speed + 5.0
        while rclpy.ok() and time.monotonic() < deadline:
            in_settle = (time.monotonic() - move_start) < ctx.settle_time_s
            # 접촉 판정: 지정 방향의 반력이 임계 이상일 때만. +X 접근 시 물체
            # 반력은 -X 이므로 기본 contact_force_dir=-1.
            fx = read_tool_force_x()
            x_hit = (fx is not None
                     and ctx.contact_force_dir * fx >= ctx.contact_force_n)
            now = time.monotonic()
            if now - last_diag >= 0.5:
                last_diag = now
                if fx is not None:
                    peak_fx = max(peak_fx, abs(fx))
                    phase = "settling" if in_settle else "monitoring"
                    logger.info(
                        f"[{label}] ({phase}) Fx={fx:.2f} N, peak={peak_fx:.2f}, "
                        f"dir={ctx.contact_force_dir:+.0f} thr={ctx.contact_force_n:.1f}")
            if x_hit and not in_settle:
                robot.stop()
                logger.warning(f"[{label}] X CONTACT (Fx={fx:.2f} N). Stop.")
                outcome = "contact"
                break
            if d.check_motion() != d.DR_STATE_IDLE:
                motion_seen = True
            elif motion_seen:
                outcome = "reached_depth"
                break
            time.sleep(ctx.poll_period_s)

        if outcome is None:
            logger.error(f"[{label}] 모니터링 타임아웃 — 정지")
            robot.stop()
        if not robot.wait_until_idle(timeout_sec=2.0):
            raise RuntimeError(f"{label}: 정지 후 idle 아님")
        fsm["motion_active"] = False
        if outcome is None:
            raise RuntimeError(f"{label}: monitoring timed out")
        return outcome

    # ===================== 실행 시퀀스 =====================
    try:
        dx, dy, dz = ctx.detection_ready_xyz
        orient = list(ctx.grasp_orientation)

        say("CUP_DETECT", "안전 자세 이동")
        move_joint(ctx.approach_joint, "movej safe posture")

        # 닫힌 강체로 탐지 오차를 줄인다.
        if ctx.close_gripper_on_start:
            gripper.close()
            time.sleep(0.5)

        say("CUP_DETECT", "감지 준비 위치", progress_in_step=0.3)
        move_line([dx, dy, dz] + orient, "move to detection-ready")
        time.sleep(1.0)

        if ctx.detect_enabled:
            say("CUP_DETECT", "+X 접촉 탐지 중", progress_in_step=0.6)
            d.set_ref_coord(d.DR_BASE)
            if d.task_compliance_ctrl(stx=ctx.stiffness, time=0.5) != 0:
                raise RuntimeError("task_compliance_ctrl failed")
            fsm["compliance_active"] = True
            time.sleep(0.6)
            logger.info("compliance ON (X soft), probing +X")
            outcome = probe_forward_x([dx, dy, dz] + orient, "probe +X")
            d.release_compliance_ctrl()
            fsm["compliance_active"] = False
            time.sleep(0.3)
            if outcome != "contact":
                logger.warning("탐지 깊이까지 갔는데 접촉 없음 — 물체 없음")
                result["reason"] = "no contact within probe depth"
                return result
        else:
            move_line([dx + ctx.sim_probe_x_mm, dy, dz] + orient,
                      "probe +X (sim fixed advance)")

        contact_raw, _ = d.get_current_posx(ref=d.DR_BASE)
        contact_pose = [float(v) for v in contact_raw[:6]]
        result["found"] = True
        result["contact_pose"] = contact_pose
        cx = contact_pose[0]
        logger.info(f"X contact at pose={contact_pose} "
                    f"(dY={contact_pose[1]-dy:.1f} dZ={contact_pose[2]-dz:.1f})")

        # 파지 기하: 접촉에서 취하는 건 X뿐(물체반경 후퇴). Y/Z는 컴플라이언스
        # 드리프트로 오염된 contact 값 대신 탐지 평면 지령값(dy, dz)을 쓴다.
        grasp_x = cx + ctx.object_radius_mm
        grasp_z = dz + ctx.grasp_z_above_center_mm
        out_pose = [cx, dy + ctx.grasp_y_standoff_mm, grasp_z] + orient
        entry_pose = [grasp_x, dy + ctx.grasp_y_standoff_mm, grasp_z] + orient
        grasp_pose = [grasp_x, dy + ctx.grasp_y_offset_mm, grasp_z] + orient
        result["grasp_pose"] = grasp_pose

        say("CUP_GRIP", "파지 진입")
        time.sleep(0.5)
        move_line(out_pose, "safe out")
        move_line(entry_pose, "safe entry at +Y standoff (Z held)")
        gripper.open_wide()
        move_line(grasp_pose, "approach grip at +Y offset (enter -Y, Z held)")

        if ctx.verify_grip:
            grip_ok, reason = gripper.close_and_verify("컵")
        else:
            gripper.close()
            time.sleep(1.0)
            grip_ok, reason = True, "verification disabled"
        result["grip_ok"], result["reason"] = grip_ok, reason

        say("CUP_PLACE", "상승 후 이송", progress_in_step=0.3)
        lift_raw, _ = d.get_current_posx(ref=d.DR_BASE)
        lift_pose = [float(v) for v in lift_raw[:6]]
        lift_pose[2] += ctx.retreat_z_mm
        move_line(lift_pose, "lift +Z after grip")

        move_line(list(ctx.place_via_pose), "move to place via-waypoint")
        move_line(list(ctx.place_pose), "move to place target")
        gripper.open_wide()
        time.sleep(0.5)

        final_raw, _ = d.get_current_posx(ref=d.DR_BASE)
        result["final_pose"] = [float(v) for v in final_raw[:6]]
        logger.info(f"probe_grip DONE grip_ok={result['grip_ok']} "
                    f"final={result['final_pose']}")
        return result

    except BaseException as exc:  # 정지 후 재전파 (실기 안전)
        logger.error(f"probe_grip aborted: {exc}")
        if fsm["motion_active"]:
            try:
                robot.stop()
                robot.wait_until_idle(timeout_sec=2.0)
                fsm["motion_active"] = False
            except Exception as stop_exc:
                logger.error(f"stop failed: {stop_exc}")
        raise
    finally:
        if fsm["compliance_active"] and not fsm["motion_active"]:
            try:
                d.release_compliance_ctrl()
            except Exception as exc:
                logger.error(f"release_compliance_ctrl failed: {exc}")


# ---------------- 단독 실행(파라미터 튜닝용) ----------------

def _ctx_from_params(node, robot, gripper):
    """CLI: declare_parameter 값으로 컨텍스트를 채운다. 미장전/검증실패면 None."""
    logger = node.get_logger()
    p = node.declare_parameter
    p("arm", False)
    p("tcp_name", "")
    p("detect_enabled", True)
    p("speed_mm_s", 40.0)
    p("acc_mm_s2", 40.0)
    p("approach_joint", [0.0, 0.0, 90.0, 90.0, -90.0, 0.0])
    p("joint_speed_deg_s", 30.0)
    p("joint_acc_deg_s2", 30.0)
    p("grasp_orientation", [-90.0, 90.0, 90.0])
    p("detection_ready_xyz", [300.0, -600.0, 110.0])
    p("close_gripper_on_start", True)
    p("sim_probe_x_mm", 150.0)
    p("probe_x_depth_mm", 200.0)
    p("contact_force_n", 8.5)
    p("contact_force_dir", -1.0)
    p("poll_period_s", 0.02)
    p("settle_time_s", 0.6)
    p("stiffness", [200.0, 3000.0, 3000.0, 200.0, 200.0, 200.0])
    p("object_radius_mm", 45.0)
    p("grasp_y_standoff_mm", 100.0)
    p("grasp_y_offset_mm", 15.0)
    p("grasp_z_above_center_mm", 0.0)
    p("retreat_z_mm", 100.0)
    p("place_via_pose", [779.0, -352.0, 400.0, 148.0, -90.0, -90.0])
    p("place_pose", [740.0, -600.0, 165.0, 125.0, -90.0, -90.0])
    p("verify_grip", True)

    g = lambda n: node.get_parameter(n).value  # noqa: E731
    if not bool(g("arm")):
        logger.error("로봇 미장전(arm) — 모션 없음. -p arm:=true 로 재실행")
        return None
    contact_force = float(g("contact_force_n"))
    if not 3.0 <= contact_force <= 30.0:
        logger.error("contact_force_n은 [3, 30] 범위")
        return None
    if float(g("contact_force_dir")) not in (-1.0, 1.0):
        logger.error("contact_force_dir는 -1.0 또는 +1.0")
        return None
    if len(list(g("grasp_orientation"))) != 3 or len(list(g("detection_ready_xyz"))) != 3:
        logger.error("grasp_orientation / detection_ready_xyz는 값 3개")
        return None
    if len(list(g("place_pose"))) != 6 or len(list(g("place_via_pose"))) != 6:
        logger.error("place_pose / place_via_pose는 값 6개 [x,y,z,A,B,C]")
        return None

    return ProbeGripContext(
        robot=robot, gripper=gripper,
        detection_ready_xyz=[float(v) for v in g("detection_ready_xyz")],
        grasp_orientation=[float(v) for v in g("grasp_orientation")],
        approach_joint=[float(v) for v in g("approach_joint")],
        speed_mm_s=float(g("speed_mm_s")), acc_mm_s2=float(g("acc_mm_s2")),
        joint_speed_deg_s=float(g("joint_speed_deg_s")),
        joint_acc_deg_s2=float(g("joint_acc_deg_s2")),
        detect_enabled=bool(g("detect_enabled")),
        sim_probe_x_mm=float(g("sim_probe_x_mm")),
        probe_x_depth_mm=float(g("probe_x_depth_mm")),
        contact_force_n=contact_force,
        contact_force_dir=float(g("contact_force_dir")),
        poll_period_s=float(g("poll_period_s")),
        settle_time_s=float(g("settle_time_s")),
        stiffness=[float(v) for v in g("stiffness")],
        object_radius_mm=float(g("object_radius_mm")),
        grasp_y_standoff_mm=float(g("grasp_y_standoff_mm")),
        grasp_y_offset_mm=float(g("grasp_y_offset_mm")),
        grasp_z_above_center_mm=float(g("grasp_z_above_center_mm")),
        retreat_z_mm=float(g("retreat_z_mm")),
        place_via_pose=[float(v) for v in g("place_via_pose")],
        place_pose=[float(v) for v in g("place_pose")],
        close_gripper_on_start=bool(g("close_gripper_on_start")),
        verify_grip=bool(g("verify_grip")),
        tcp_name=str(g("tcp_name")) or None,
    )


def main(args=None):
    from coffee_pipeline.gripper import Gripper
    from coffee_pipeline.robot import Robot, create_node

    rclpy.init(args=args)
    node = create_node("probe_grip")
    try:
        node.declare_parameter("gripper_channel", "service")
        robot = Robot.connect(node)
        gripper = Gripper(robot, channel=node.get_parameter("gripper_channel").value)
        ctx = _ctx_from_params(node, robot, gripper)
        if ctx is None:
            return
        run_once(ctx)
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
