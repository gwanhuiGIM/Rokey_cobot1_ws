# =============================================================
# process_state.py — 통합 공정 상태머신 정의 + 보고 메시지 규약
# -------------------------------------------------------------
# 실행: 라이브러리 (자체 점검: python3 -m coffee_pipeline.process_state --selftest)
# 토픽: /coffee_process/state — std_msgs/String (JSON 1줄)
#       QoS: RELIABLE / TRANSIENT_LOCAL / depth 10
#       -> 모니터를 나중에 켜도 마지막 상태를 바로 받는다
# 의존: rclpy, std_msgs
# -------------------------------------------------------------
# STEPS는 실제 커피 추출 5단계 전체를 담는다 (2026-07-28, src/rokey/rokey/
# coffee_system.py 최신본 반영 후 확정 — 이전 세션의 "6단계 예약표"는
# 컵 서빙을 추측했었는데 실물 코드에는 그런 단계가 없다. 실제로는:
#   1) 원두    : SELECT_BEAN -> BEAN_DROP        (스푼 파지 -> 그라인더 투입)
#   2) 그라인딩 : SELECT_GRIND -> GRINDING        (회전 분쇄까지)
#   3) 운반    : BOTTLE_PICK -> BOTTLE_MOVE -> WAIT_TAP -> BOTTLE_RETURN
#              (병 파지부터 힘제어 외력 감지까지)
#   4) 핸드드립 : HAND_DRIP                       (주전자 파지 -> 내향 스파이럴 붓기)
#   5) 최종 붓기: FINAL_POUR                      (필터홀더+물컵 배치 -> 위치보상 붓기)
#   컵 접촉 탐지(probe_grip)는 이 공정과 무관한 별개 모듈이다 — "5단계 자리
#   예약"이 아니라 그냥 독립 노드로 남는다 (docs/plans/2026-07-27-full-6-stage-flow.md
#   참고, 정정 내용 그 파일 상단에 있음).
#   이 리스트가 상태머신의 단일 진실 소스라 순서를 바꾸면 진행률·모니터의
#   "건너뜀 감지"·대시보드 칩이 전부 따라온다.
#
# 사용법 (로봇을 실제로 움직이는 쪽에서):
#   from coffee_pipeline.process_state import ProcessReporter, STEP
#   report = ProcessReporter(node)
#   report.set(STEP.SELECT_BEAN, waiting="DI13~16")
#   report.set(STEP.GRINDING, progress_in_step=0.4, message="3/7 회전")
#   report.set(STEP.HAND_DRIP, progress_in_step=0.5,
#              detail={"spiral_stage": "스파이럴 드립", "spiral_progress": 35.0})
#   report.error("그리퍼가 컵을 놓쳤다")
#
# detail: 웹 UI(web_ui.py)의 고객 화면이 쓰는 자유 형식 JSON(선택). 예:
#   grind_current_turns, spiral_stage/progress, final_drip_stage/progress,
#   force_delta_n/peak_n. STEPS 정의를 안 건드리고 붙였다 뗐다 할 수 있게
#   dict 통으로 넘긴다 — 필드가 늘 때마다 encode()를 고치지 않아도 된다.
#
# ponytail: 커스텀 .msg 대신 String+JSON. 필드가 아직 굳지 않았고 ament_python
#   패키지라 .msg를 만들려면 인터페이스 패키지가 따로 필요하다.
# =============================================================

import json
import time

from rclpy.qos import (
    QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy,
)
from std_msgs.msg import String

TOPIC = "/coffee_process/state"

# 공정 순서 (key, 화면 라벨, 대기 조건 힌트). 상태머신의 유일한 정의.
STEPS = [
    ("INIT",         "초기화",             ""),
    ("HOME",         "홈 위치 이동",        ""),
    ("SELECT_BEAN",  "원두 선택 대기",      "DI 13~16"),
    ("BEAN_DROP",    "원두 투입",           ""),
    ("SELECT_GRIND", "분쇄 굵기 선택 대기",  "DI 13~16"),
    ("GRINDING",     "분쇄",               ""),
    ("BOTTLE_PICK",  "병 파지",            ""),
    ("BOTTLE_MOVE",  "갈린 원두 운반",      ""),
    ("WAIT_TAP",     "병 두드림 대기",      "외력 감지"),
    ("BOTTLE_RETURN", "병 원위치",          ""),
    ("HAND_DRIP",    "핸드드립 (스파이럴)", ""),
    ("FINAL_POUR",   "최종 물 붓기",        ""),
    ("DONE",         "1 사이클 완료",       ""),
]
# 더 붙일 자리가 생기면: DONE 앞에 (키, 라벨, 대기힌트) 줄만 추가하면
# 진행률·대시보드 칩·건너뜀 감지가 전부 따라온다.
STEP_KEYS = [key for key, _label, _hint in STEPS]
STEP_INDEX = {key: i for i, key in enumerate(STEP_KEYS)}
STEP_LABEL = {key: label for key, label, _hint in STEPS}
STEP_HINT = {key: hint for key, _label, hint in STEPS}

# 언제든 돌아갈 수 있는 스텝(중단·재시작·사이클 반복) — 건너뜀 경고 예외.
RESET_STEPS = ("INIT", "SELECT_BEAN")


class STEP:
    """오타 방지용 상수 네임스페이스 (STEP.GRINDING 처럼 사용)."""


for _key in STEP_KEYS:
    setattr(STEP, _key, _key)

STATUSES = ("RUNNING", "WAITING", "DONE", "ERROR")

# 컨트롤박스 디지털 입력 배치.
# 주의: DRL의 get_digital_input(n)은 1-based, ROS 토픽
# io/ctrl_box_digital_input_state의 data[i]는 DI[i+1] -> 배열 인덱스 = n-1.
DI_LABELS = {
    13: "원두1 / 굵게(3회전)",
    14: "원두2 / 중간굵게(5회전)",
    15: "원두3 / 중간곱게(7회전)",
    16: "원두4 / 곱게(10회전)",
}
# 각 대기 상태를 푸는 대표 버튼 (실제로는 13~16 아무거나 = 선택지).
# 대시보드가 int 하나를 기대하므로 대표값만 넣는다.
DI_TRIGGER = {"SELECT_BEAN": 13, "SELECT_GRIND": 13}

# 가상 버튼: 물리 DI 대신 이 토픽(std_msgs/UInt8, 값 = DI 번호)으로도 누른다.
#   ros2 topic pub --once /coffee_process/button_press std_msgs/msg/UInt8 "{data: 13}"
# 여기 두는 이유: buttons.py(로봇측)와 dashboard.py(모니터측)가 공유하는데
# dashboard는 dsr_msgs2를 import하면 안 되므로 SDK-free 모듈에 둬야 한다.
BUTTON_PRESS_TOPIC = "/coffee_process/button_press"


def step_progress(step):
    """공정 전체 진행률 [%] — 스텝 순서에서 자동 계산 (매직넘버 없음)."""
    return round(100.0 * STEP_INDEX[step] / (len(STEPS) - 1), 1)


def is_expected_transition(prev_step, step):
    """상태머신 검증: 정의된 순서대로 왔는가.

    허용: 첫 보고 / 같은 스텝 재보고 / 바로 다음 스텝 / RESET_STEPS 복귀 /
    뒤 스텝으로 되돌아감(단계 실패 후 재시도 — home()을 거쳐 앞 스텝부터 다시 감).
    그 외(앞으로 건너뜀)만 경고 대상이다.
    """
    if prev_step is None or prev_step == step:
        return True
    if step in RESET_STEPS:
        return True
    if STEP_INDEX.get(step, -1) < STEP_INDEX.get(prev_step, -99):
        return True
    return STEP_INDEX.get(step, -1) == STEP_INDEX.get(prev_step, -99) + 1


def encode(step, status="RUNNING", message="", progress_in_step=None, detail=None):
    """공정 보고 1건 -> JSON 문자열.

    progress_in_step: 분쇄·드립처럼 오래 걸리는 스텝의 내부 진행도(0.0~1.0).
    주면 전체 진행률이 다음 스텝까지 그만큼 선형 보간된다.
    detail: 웹 UI 등이 쓰는 자유 형식 dict(선택, 위 헤더 주석 참고).
    """
    if step not in STEP_INDEX:
        raise ValueError(f"unknown step: {step}")
    if status not in STATUSES:
        raise ValueError(f"unknown status: {status}")

    progress = step_progress(step)
    if progress_in_step is not None:
        span = 100.0 / (len(STEPS) - 1)
        progress = round(progress + span * min(1.0, max(0.0, progress_in_step)), 1)
    return json.dumps({
        "step": step,
        "index": STEP_INDEX[step],
        "total": len(STEPS),
        "label": STEP_LABEL[step],
        "hint": STEP_HINT[step],
        "status": status,
        "message": message,
        "progress": progress,
        "detail": detail or {},
        "stamp": time.time(),
    })


def decode(text):
    payload = json.loads(text)
    if payload.get("step") not in STEP_INDEX:
        raise ValueError(f"unknown step: {payload.get('step')}")
    if payload.get("status") not in STATUSES:
        raise ValueError(f"unknown status: {payload.get('status')}")
    return payload


def qos():
    return QoSProfile(
        reliability=ReliabilityPolicy.RELIABLE,
        durability=DurabilityPolicy.TRANSIENT_LOCAL,
        history=HistoryPolicy.KEEP_LAST,
        depth=10,
    )


class ProcessReporter:
    """자동화 노드가 공정 상태를 모니터로 보내는 한 줄짜리 창구."""

    def __init__(self, node, topic=TOPIC):
        self.node = node
        self.pub = node.create_publisher(String, topic, qos())
        self.step = None

    def set(self, step, message="", progress_in_step=None, waiting=None, detail=None):
        """waiting에 'DI13' 같은 문자열을 주면 상태가 WAITING으로 나간다."""
        status = "WAITING" if waiting else ("DONE" if step == "DONE" else "RUNNING")
        if waiting and not message:
            message = f"{waiting} 입력 대기"
        self.pub.publish(String(
            data=encode(step, status, message, progress_in_step, detail)))
        self.step = step

    def error(self, message):
        """현재 스텝에서 이상 발생. 스텝은 유지한 채 상태만 ERROR."""
        step = self.step or "INIT"
        self.pub.publish(String(data=encode(step, "ERROR", message)))


def _demo():
    assert STEP.GRINDING == "GRINDING"
    assert step_progress("INIT") == 0.0
    assert step_progress("DONE") == 100.0

    payload = decode(encode(STEP.GRINDING, "RUNNING", "test"))
    assert payload["step"] == "GRINDING"
    assert payload["label"] == "분쇄"
    assert payload["index"] == STEP_INDEX["GRINDING"]

    # 스텝 내부 진행도는 다음 스텝 사이를 선형 보간
    half = decode(encode(STEP.GRINDING, progress_in_step=0.5))["progress"]
    assert step_progress("GRINDING") < half < step_progress("BOTTLE_PICK"), half
    full = decode(encode(STEP.GRINDING, progress_in_step=1.0))["progress"]
    assert abs(full - step_progress("BOTTLE_PICK")) < 0.2, full

    # detail은 선택 필드: 안 주면 빈 dict, 주면 그대로 실린다
    assert decode(encode(STEP.HAND_DRIP))["detail"] == {}
    with_detail = decode(encode(STEP.HAND_DRIP, detail={"spiral_progress": 42.0}))
    assert with_detail["detail"]["spiral_progress"] == 42.0

    for bad in (lambda: encode("NOPE"), lambda: encode("INIT", "BOOM"),
                lambda: decode('{"step":"NOPE","status":"RUNNING"}')):
        try:
            bad()
        except ValueError:
            pass
        else:
            raise AssertionError("검증 없이 통과됨")

    assert is_expected_transition(None, "INIT")
    assert is_expected_transition("SELECT_BEAN", "BEAN_DROP")
    assert is_expected_transition("GRINDING", "GRINDING")
    assert is_expected_transition("DONE", "SELECT_BEAN")     # 사이클 반복
    assert is_expected_transition("BOTTLE_MOVE", "INIT")     # 중단 후 재초기화
    assert is_expected_transition("GRINDING", "HOME")        # 단계 실패 후 재시도(뒤로 감)
    assert not is_expected_transition("SELECT_BEAN", "GRINDING")  # 스텝 건너뜀

    assert set(DI_TRIGGER) <= set(STEP_KEYS)
    assert all(isinstance(v, int) for v in DI_TRIGGER.values())  # 대시보드 계약
    print("process_state self-check OK")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--selftest":
        _demo()
