# =============================================================
# robot.py — DSR 세션 1개 = 프로세스 1개 (모션 명령의 유일한 창구)
# -------------------------------------------------------------
# 실행: 라이브러리
# 의존: rclpy, DR_init, DSR_ROBOT2, dsr_msgs2
# -------------------------------------------------------------
# 왜 있나: 통합 전 두 모듈(m0609_coffee_system_v2, probe_grip_v2)이 각각
#   노드를 만들고 DR_init.__dsr__node 를 자기 것으로 덮어썼다. DSR_ROBOT2는
#   전역 노드 하나를 공유하므로 한 프로세스에 DSR 모션 노드는 '하나'여야 한다.
#   이 파일이 그 하나를 만들고 두 모듈에 넘긴다.
#
# 담고 있는 것 (원본에서 검증된 회피책들)
# - connect(): DSR_ROBOT2 import 직후 ~100개 서비스 클라이언트가 discovery를
#   끝내기 전에 호출하면 응답이 영영 안 오는 문제 -> 대표 서비스 1개가 실제로
#   매칭될 때까지 대기 (고정 sleep은 부하에 따라 부족했던 실패 사례 있음).
# - apply_tcp(): set_tcp()를 ROS2 서비스로 직접 부르면 컨트롤러가 "manual mode
#   전용"이라며 거부한다(실측 100% 거부). drl_script_run()으로 한 줄짜리 DRL을
#   돌려서 통과시킨다. 그래서 TCP 변경 경로는 이거 하나로 통일했다.
# =============================================================

import time

import DR_init
from dsr_msgs2.srv import MoveJoint, MoveStop

ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"

# 티치펜던트에 등록된 이름 (없으면 set_tool_tcp()가 여기서 멈춘다)
TOOL_NAME = "Tool Weight123"
TCP_NAME = "GripperDA_v1"

# 전역 모션 파라미터 (원본 DRL 하단 설정값)
VELJ_DEFAULT = 20.0
ACCJ_DEFAULT = 35.0
VELX_LIN_DEFAULT = 80.0
VELX_ROT_DEFAULT = 25.0
ACCX_LIN_DEFAULT = 300.0
ACCX_ROT_DEFAULT = 100.0

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL


def create_node(node_name):
    """네임스페이스(dsr01)까지 맞춘 노드 생성. rclpy.init()은 호출자 책임."""
    import rclpy

    return rclpy.create_node(node_name, namespace=ROBOT_ID)


def bind_dsr_node(node):
    """DSR_ROBOT2가 쓸 전역 노드를 꽂는다. **반드시 모듈 레벨 함수여야 한다.**

    클래스 몸통 안에서 `DR_init.__dsr__node = node` 를 쓰면 파이썬 이름 맹글링이
    `DR_init._Robot__dsr__node` 로 바꿔 저장한다 → DSR_ROBOT2는 여전히 None을 보고
    `'NoneType' object has no attribute 'create_client'` 로 죽는다 (실측).
    """
    DR_init.__dsr__node = node


class Robot:
    """DSR 세션. `robot.dsr.<api>` 로 DSR_ROBOT2 API에 그대로 접근한다.

    (원본 커피 노드는 40개 API를 지역 변수로 재바인딩했는데, 이름만 늘고
     얻는 게 없어서 없앴다 — 호출부에서 `d = robot.dsr` 한 줄이면 끝.)
    """

    def __init__(self, node, dsr):
        self.node = node
        self.dsr = dsr
        self.log = node.get_logger()
        self._stop_client = node.create_client(MoveStop, "motion/move_stop")

    @classmethod
    def connect(cls, node):
        """컨트롤러 서비스가 실제로 뜰 때까지 기다린 뒤 DSR_ROBOT2를 붙인다."""
        bind_dsr_node(node)
        probe = node.create_client(MoveJoint, "motion/move_joint")
        while not probe.wait_for_service(timeout_sec=1.0):
            node.get_logger().info("컨트롤러 서비스 연결 대기 중...")
        node.destroy_client(probe)

        import DSR_ROBOT2 as dsr

        node.get_logger().info("DSR_ROBOT2 연결 완료")
        return cls(node, dsr)

    # ---------- 초기 설정 ----------

    def apply_motion_defaults(self):
        d = self.dsr
        d.set_singularity_handling(d.DR_AVOID)
        d.set_velj(VELJ_DEFAULT)
        d.set_accj(ACCJ_DEFAULT)
        # set_velx()는 (vel1, vel2) 2인자까지만 받는다. 원본의 3번째 인자 DR_OFF는
        # DSR_ROBOT2에 상수 자체가 없어 AttributeError로 죽던 코드라 제거된 상태.
        d.set_velx(VELX_LIN_DEFAULT, VELX_ROT_DEFAULT)
        d.set_accx(ACCX_LIN_DEFAULT, ACCX_ROT_DEFAULT)

    def set_tool_tcp(self, tool_name=TOOL_NAME, tcp_name=TCP_NAME):
        """Tool/TCP를 티치펜던트 등록 이름으로 맞추고 실제 반영을 확인한다."""
        d = self.dsr
        tool_ret = d.set_tool(tool_name)
        tcp_ret = d.set_tcp(tcp_name)
        active_tool, active_tcp = d.get_tool(), d.get_tcp()
        self.log.info(
            f"set_tool ret={tool_ret} 요청={tool_name} 활성={active_tool} / "
            f"set_tcp ret={tcp_ret} 요청={tcp_name} 활성={active_tcp}")
        if active_tool != tool_name or active_tcp != tcp_name:
            raise RuntimeError(
                f"Tool/TCP 활성화 실패 (요청 {tool_name}/{tcp_name}, "
                f"실제 {active_tool}/{active_tcp}). 티치펜던트 등록 이름 확인.")

    def apply_tcp(self, name, timeout_sec=6.0, poll_interval=0.1):
        """TCP 전환의 유일한 경로. drl_script_run()으로 set_tcp를 실행한다.

        AUTO 모드에서 set_tcp() 서비스는 컨트롤러가 거부하므로(위 헤더 참고)
        모션 중 TCP를 바꿔야 할 때는 반드시 이 함수를 쓴다. 성공 여부를 bool로
        돌려주고, 실패해도 예외를 던지지 않는다 — 물체를 잡은 채 멈추는 게 더
        위험한 구간에서 쓰이기 때문(호출자가 판단).
        """
        d = self.dsr
        code = f'set_tcp("{name}")'
        if d.drl_script_run(d.get_robot_system(), code) != 0:
            self.log.error(f"drl_script_run 시작 실패: {code!r}")
            return False

        deadline = time.monotonic() + timeout_sec
        while d.get_drl_state() == 0:  # 0=PLAY, 1=STOP, 2=HOLD, 3=LAST
            if time.monotonic() >= deadline:
                self.log.error(f"drl_script_run({code!r}) {timeout_sec:.0f}초 내 미완료")
                return False
            time.sleep(poll_interval)

        active = d.get_tcp()
        if active != name:
            self.log.error(f"set_tcp('{name}') 미반영: 실제 활성={active}")
            return False
        return True

    # ---------- 정지 (예외 처리 경로) ----------

    def stop(self, stop_mode=None, timeout_sec=2.0):
        """모션 급정지. 예외 핸들러에서 부른다. stop_mode 기본 = DR_QSTOP."""
        import rclpy

        if stop_mode is None:
            stop_mode = self.dsr.DR_QSTOP
        if not self._stop_client.wait_for_service(timeout_sec=timeout_sec):
            raise RuntimeError("move_stop 서비스 없음")
        future = self._stop_client.call_async(MoveStop.Request(stop_mode=stop_mode))
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=timeout_sec)
        if not future.done() or future.result() is None:
            raise RuntimeError("move_stop 응답 없음")
        if not future.result().success:
            raise RuntimeError("move_stop 거부됨")

    def wait_until_idle(self, timeout_sec=2.0):
        d = self.dsr
        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            if d.check_motion() == d.DR_STATE_IDLE:
                return True
            time.sleep(0.02)
        return False
