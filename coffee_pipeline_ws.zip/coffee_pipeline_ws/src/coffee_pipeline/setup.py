from glob import glob

from setuptools import find_packages, setup

package_name = 'coffee_pipeline'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='kimkh',
    maintainer_email='sbzmf1@o.cnu.ac.kr',
    description='M0609 + RG2 커피 공정 통합 (커피 시퀀스 + 컵 접촉파지 + 시스템 모니터 + 웹UI)',
    license='MIT',
    extras_require={
        'test': [
            'pytest',
        ],
        # web_ui.py 전용 — rosdep 키가 없어 package.xml이 아니라 여기 적는다.
        'web_ui': [
            'fastapi',
            'uvicorn',
        ],
    },
    entry_points={
        'console_scripts': [
            'orchestrator = coffee_pipeline.orchestrator:main',
            'probe_grip = coffee_pipeline.probe_grip:main',
            'system_monitor = coffee_pipeline.system_monitor:main',
            'dashboard = coffee_pipeline.dashboard:main',
            'web_ui = coffee_pipeline.web_ui:main',
        ],
    },
)
