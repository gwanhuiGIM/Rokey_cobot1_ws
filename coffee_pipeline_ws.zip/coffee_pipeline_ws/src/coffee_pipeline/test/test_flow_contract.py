# =============================================================
# test_flow_contract.py — 통합 계약 검사 (로봇·ROS 불필요)
# -------------------------------------------------------------
# 실행: pytest src/coffee_pipeline/test/test_flow_contract.py
# 검증: (1) 모션 모듈이 보고하는 스텝이 전부 process_state.STEPS에 있는가
#       (2) 통합 플로우 순서가 상태머신 규칙을 만족하는가(건너뜀 없음)
# 왜: STEPS 순서를 바꾸거나 스텝 이름을 오타내면 모니터가 조용히 WARN만
#     찍고 지나간다. 여기서 먼저 깨지게 한다.
# 소스는 import 대신 텍스트로 읽는다 — coffee_steps/probe_grip은 DSR SDK가
# 깔린 환경에서만 import되기 때문(CI/노트북에서도 이 테스트는 돌아야 한다).
# =============================================================

import pathlib
import re

from coffee_pipeline import process_state as ps

SRC = pathlib.Path(__file__).resolve().parents[1] / "coffee_pipeline"
# probe_grip은 공정에서 분리돼 자체 로그만 남긴다(스텝 계약 대상 아님).
MOTION_MODULES = ("coffee_steps.py", "orchestrator.py")

# orchestrator가 실제로 밟는 순서 (README §플로우와 같아야 한다)
FLOW = [
    "INIT", "HOME",
    "SELECT_BEAN", "BEAN_DROP",                                  # 1단계 원두
    "SELECT_GRIND", "GRINDING",                                  # 2단계 그라인딩
    "BOTTLE_PICK", "BOTTLE_MOVE", "WAIT_TAP", "BOTTLE_RETURN",   # 3단계 운반
    "HAND_DRIP",                                                  # 4단계 핸드드립
    "FINAL_POUR",                                                 # 5단계 최종 붓기
    "DONE",
]


def test_reported_steps_exist():
    for name in MOTION_MODULES:
        text = (SRC / name).read_text(encoding="utf-8")
        used = set(re.findall(r'_?say\(\s*"([A-Z_]+)"', text))
        used |= set(re.findall(r'STEP\.([A-Z_]+)\b', text))
        unknown = used - set(ps.STEP_KEYS)
        assert not unknown, f"{name}: STEPS에 없는 스텝 {sorted(unknown)}"


def test_flow_matches_state_machine():
    assert FLOW == ps.STEP_KEYS, "FLOW와 STEPS 정의가 어긋남"
    previous = None
    for step in FLOW:
        assert ps.is_expected_transition(previous, step), f"건너뜀: {previous} -> {step}"
        previous = step
    assert ps.is_expected_transition("DONE", "SELECT_BEAN")   # 사이클 반복
    assert ps.step_progress(FLOW[-1]) == 100.0


def test_process_state_selftest():
    ps._demo()
