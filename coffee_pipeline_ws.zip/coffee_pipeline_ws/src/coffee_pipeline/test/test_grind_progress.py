# =============================================================
# test_grind_progress.py — 분쇄 회전량 누적 검사 (로봇 불필요, DSR SDK만 필요)
# -------------------------------------------------------------
# 검증: CoffeeSteps._grind_arc 가 좌표계 101의 X/Y 각도만 보고
#       실제 회전수를 맞게 세는가 (방향 판정 · ±180° 랩 · 역회전 제거).
# 왜: 부호 하나 틀리면 진행률이 0%에 붙박이거나 1회전 만에 100%가 된다.
#     실기에서만 드러나면 늦다.
# coffee_steps는 DSR SDK가 깔린 환경에서만 import된다 -> 없으면 skip.
# =============================================================

import math

import pytest

pytest.importorskip("DR_init")

from coffee_pipeline import coffee_steps as cs  # noqa: E402

ARC_RADIUS_MM = 124.5


class FakeDsr:
    """미리 정한 각도열(deg)을 그대로 돌려주는 가짜 컨트롤러.

    각도가 다 소진되면 check_motion()이 IDLE을 반환해 모션 종료로 보인다.
    """

    DR_STATE_IDLE = 0
    DR_MV_RA_OVERRIDE = 1

    def __init__(self, angles_deg):
        self.angles = list(angles_deg)
        self.index = 0
        self.mwait_calls = 0
        self.commanded = None

    @staticmethod
    def posx(values):
        return list(values)

    def amovec(self, pos1, pos2, **kwargs):
        self.commanded = kwargs

    def check_motion(self):
        return self.DR_STATE_IDLE if self.index >= len(self.angles) else 2

    def get_current_posx(self, ref=None):
        assert ref == cs.GRIND_USER_COORD
        deg = self.angles[min(self.index, len(self.angles) - 1)]
        self.index += 1
        return [ARC_RADIUS_MM * math.cos(math.radians(deg)),
                ARC_RADIUS_MM * math.sin(math.radians(deg)),
                -5.0, 90.0, -179.99, 88.27], 2

    def mwait(self, t=0):
        self.mwait_calls += 1


def _make_steps(dsr, monkeypatch):
    """_grind_arc만 돌리기 위한 최소 CoffeeSteps. (msg, progress) 기록도 반환."""
    monkeypatch.setattr(cs, "GRIND_PROGRESS_POLL_SEC", 0.0)
    monkeypatch.setattr(cs.rclpy, "ok", lambda: True)
    reported = []
    warnings = []

    steps = cs.CoffeeSteps.__new__(cs.CoffeeSteps)
    steps.d = dsr
    steps.log = type("Log", (), {"warning": staticmethod(warnings.append)})()
    steps.report = None
    steps._say = lambda step, msg="", progress_in_step=None, waiting=None: (
        reported.append((msg, progress_in_step)))
    return steps, reported, warnings


def _clockwise(total_deg, step_deg=30.0):
    """0°에서 시계방향(= 경유점 -90° 쪽)으로 total_deg 만큼 도는 각도열."""
    count = int(total_deg / step_deg)
    return [-step_deg * i for i in range(count + 1)]


def test_counts_full_turns(monkeypatch):
    dsr = FakeDsr(_clockwise(3 * 360.0))
    steps, reported, warnings = _make_steps(dsr, monkeypatch)

    steps._grind_arc(3)

    last_msg, last_progress = reported[-1]
    assert last_msg.startswith("3.0/3회전"), last_msg
    assert last_progress == pytest.approx(0.95, abs=1e-6)
    assert dsr.mwait_calls == 1
    assert not warnings
    assert dsr.commanded["angle"] == [1080.0, 0.0]


def test_progress_is_monotonic_and_bounded(monkeypatch):
    dsr = FakeDsr(_clockwise(2 * 360.0))
    steps, reported, _ = _make_steps(dsr, monkeypatch)

    steps._grind_arc(2)

    progress = [p for _, p in reported]
    assert progress == sorted(progress), progress
    assert progress[0] >= 0.2 and progress[-1] <= 0.95


def test_reverse_jitter_does_not_count(monkeypatch):
    """진행 없이 역방향(반시계)으로만 흔들리면 회전수는 0에 머물러야 한다."""
    dsr = FakeDsr([0.0, 3.0, 0.0, 3.0, 0.0, 3.0])
    steps, reported, _ = _make_steps(dsr, monkeypatch)

    steps._grind_arc(1)

    assert all(p == pytest.approx(0.2) for _, p in reported), reported


def test_service_failure_falls_back_to_mwait(monkeypatch):
    """check_motion()이 -1이면 측정을 접고 모션 종료만 기다린다 (무한루프 금지)."""
    dsr = FakeDsr(_clockwise(360.0))
    dsr.check_motion = lambda: -1
    steps, _, warnings = _make_steps(dsr, monkeypatch)

    steps._grind_arc(1)

    assert dsr.mwait_calls == 1
    assert warnings and "측정 실패" in warnings[0]


def test_check_motion_exception_does_not_kill_grind(monkeypatch):
    """실측(coffee_system_v3 대비): 서비스 future 실패 시 check_motion()은
    -1이 아니라 UnboundLocalError를 던진다(DSR_ROBOT2.py 3826행, except에서
    ret을 못 채운 채 return). try 없이 부르면 그라인딩이 그 자리에서 죽는다."""
    dsr = FakeDsr(_clockwise(360.0))

    def boom():
        raise RuntimeError("service call failed")

    dsr.check_motion = boom
    steps, _, warnings = _make_steps(dsr, monkeypatch)

    steps._grind_arc(1)          # 예외가 새면 여기서 테스트가 실패한다

    assert dsr.mwait_calls == 1
    assert warnings and "check_motion" in warnings[0]


def test_posx_read_failure_keeps_last_progress_and_finishes(monkeypatch):
    """실측(coffee_system_v3 대비): get_current_posx()는 서비스 실패 시
    (None,None)이 아니라 언패킹 불가능한 bare 0을 반환한다(DSR_ROBOT2.py 974행).
    모션은 계속 도는 중(check_motion으로 확인)이므로 이 샘플만 건너뛰고
    끝까지 완주해야 한다 — break하면 실제로는 도는데 표시만 멈춰버린다."""
    dsr = FakeDsr(_clockwise(2 * 360.0))
    real_get = dsr.get_current_posx
    calls = {"n": 0}

    def flaky_get(ref=None):
        calls["n"] += 1
        if calls["n"] == 3:
            return 0
        return real_get(ref=ref)

    dsr.get_current_posx = flaky_get
    steps, reported, warnings = _make_steps(dsr, monkeypatch)

    steps._grind_arc(2)

    assert warnings and "각도 측정 실패" in warnings[0]
    last_msg, _ = reported[-1]
    assert last_msg.startswith("2.0/2회전"), last_msg


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q", "-p", "no:anyio"]))
