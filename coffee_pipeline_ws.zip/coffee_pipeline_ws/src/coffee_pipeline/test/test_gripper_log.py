# =============================================================
# test_gripper_log.py — 파지 성공/실패가 번갈아 와도 로거가 안 죽는지
# -------------------------------------------------------------
# 실행: pytest src/coffee_pipeline/test/test_gripper_log.py
# 왜: rclpy 로거는 호출 지점(파일·줄·함수)마다 severity를 캐시한다. 한 줄에서
#     info/warning을 골라 부르면 두 번째 호출이
#     ValueError("Logger severity cannot be changed between calls.")로 죽는다.
#     실기에서 스푼 파지 성공(INFO) 다음 그라인더 손잡이 파지 실패(WARN) 순간
#     공정이 통째로 멈췄다. 스텁 로거로는 재현이 안 되므로 진짜 rclpy 로거를 쓴다.
# gripper.py는 dsr_msgs2를 import하지 않으므로 로봇 SDK 없이도 돈다.
# =============================================================

import rclpy

from coffee_pipeline.gripper import Gripper


class _StubDsr:
    ON, OFF = 1, 0

    def set_digital_output(self, index, value):
        pass


class _StubRobot:
    """Gripper가 쓰는 것만: node / log / dsr."""

    def __init__(self, node):
        self.node = node
        self.log = node.get_logger()
        self.dsr = _StubDsr()


def test_alternating_grip_result_does_not_kill_logger():
    rclpy.init()
    try:
        node = rclpy.create_node("test_gripper_log")
        gripper = Gripper(_StubRobot(node), settle_s=0.0)

        results = iter([(True, "hardware grip bit=True"),
                        (False, "hardware grip bit=False"),
                        (True, "hardware grip bit=True")])
        gripper.verify_grip = lambda *a, **k: next(results)

        # 성공 -> 실패 -> 성공. 예전 코드는 두 번째에서 ValueError로 죽었다.
        assert gripper.close_and_verify("스푼")[0] is True
        assert gripper.close_and_verify("그라인더 손잡이")[0] is False
        assert gripper.close_and_verify("병")[0] is True

        node.destroy_node()
    finally:
        rclpy.shutdown()
