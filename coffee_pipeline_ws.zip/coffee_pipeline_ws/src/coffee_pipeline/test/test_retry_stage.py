# =============================================================
# test_retry_stage.py — 단계 실패 -> 사람 개입 재시도 루프 검증 (로봇 불필요)
# -------------------------------------------------------------
# 실행: pytest src/coffee_pipeline/test/test_retry_stage.py
# 검증: run_stage()가 (1) 실패 시 정지하고 재시도/중단을 안내하는가
#       (2) RETRY_BUTTON이면 home()을 거쳐 재시도해 결국 성공하는가
#       (3) ABORT_BUTTON이면 예외를 그대로 올리는가
#       (4) KeyboardInterrupt는 재시도 루프에 갇히지 않고 즉시 올라가는가
# orchestrator.py는 DR_init이 깔린 환경에서만 import된다 -> 없으면 skip
# (test_grind_progress.py와 같은 관례).
# =============================================================

import pytest

pytest.importorskip("DR_init")

from coffee_pipeline import orchestrator as orch  # noqa: E402
from coffee_pipeline.buttons import ABORT_BUTTON, RETRY_BUTTON  # noqa: E402


class _StubLogger:
    def info(self, _text):
        pass

    warning = info
    error = info


class _StubNode:
    def get_logger(self):
        return _StubLogger()


class _StubRobot:
    def __init__(self):
        self.stop_calls = 0
        self.motion_defaults_calls = 0

    class dsr:
        @staticmethod
        def release_compliance_ctrl():
            pass

    def stop(self):
        self.stop_calls += 1

    def apply_motion_defaults(self):
        # FINAL_POUR가 실패하면 재시도 전에 항상 기본 속도로 되돌린다
        # (orchestrator.run_stage 참고) — 매 재시도마다 호출되는지 검증.
        self.motion_defaults_calls += 1


class _StubSteps:
    def __init__(self):
        self.home_calls = 0

    def home(self):
        self.home_calls += 1


class _StubButtons:
    """미리 정한 버튼열을 wait_for_button()이 순서대로 반환."""

    def __init__(self, presses):
        self._presses = iter(presses)

    def wait_for_button(self):
        return next(self._presses)


class _StubReport:
    def __init__(self):
        self.errors = []

    def error(self, message):
        self.errors.append(message)


def _flaky(fail_times, ok_result="done"):
    """처음 fail_times번은 예외, 그 다음은 성공하는 함수."""
    calls = {"n": 0}

    def fn():
        calls["n"] += 1
        if calls["n"] <= fail_times:
            raise RuntimeError(f"실패 {calls['n']}")
        return ok_result

    return fn, calls


def test_retry_button_recovers_after_grip_failure():
    node, robot, steps = _StubNode(), _StubRobot(), _StubSteps()
    buttons = _StubButtons([RETRY_BUTTON, RETRY_BUTTON])   # 2번 실패 -> 2번 재시도 -> 성공
    report = _StubReport()
    fn, calls = _flaky(fail_times=2)

    result, elapsed = orch.run_stage("BOTTLE_MOVE", fn, node, robot, steps, buttons, report)

    assert result == "done"
    assert calls["n"] == 3
    assert steps.home_calls == 2          # 재시도마다 home()부터
    assert robot.stop_calls == 2          # 실패마다 안전 정지
    assert robot.motion_defaults_calls == 2   # home() 전에 항상 기본 속도로
    assert len(report.errors) == 2
    assert f"DI{RETRY_BUTTON}=재시도" in report.errors[0]
    assert f"DI{ABORT_BUTTON}=중단" in report.errors[0]
    assert elapsed >= 0.0


def test_abort_button_raises_original_exception():
    node, robot, steps = _StubNode(), _StubRobot(), _StubSteps()
    buttons = _StubButtons([ABORT_BUTTON])
    report = _StubReport()
    fn, calls = _flaky(fail_times=99)

    with pytest.raises(RuntimeError, match="실패 1"):
        orch.run_stage("GRINDING", fn, node, robot, steps, buttons, report)

    assert calls["n"] == 1
    assert steps.home_calls == 0          # 중단이므로 재시도 안 함
    assert robot.stop_calls == 1
    assert robot.motion_defaults_calls == 0   # 재시도 안 하므로 속도 복원도 없음


def test_keyboard_interrupt_skips_retry_prompt():
    node, robot, steps = _StubNode(), _StubRobot(), _StubSteps()
    buttons = _StubButtons([])             # 대기까지 못 감 -> 호출되면 StopIteration으로 실패
    report = _StubReport()

    def fn():
        raise KeyboardInterrupt

    with pytest.raises(KeyboardInterrupt):
        orch.run_stage("BEAN_DROP", fn, node, robot, steps, buttons, report)

    assert not report.errors                # 재시도 안내조차 하지 않는다
    assert robot.stop_calls == 0


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q", "-p", "no:anyio"]))
