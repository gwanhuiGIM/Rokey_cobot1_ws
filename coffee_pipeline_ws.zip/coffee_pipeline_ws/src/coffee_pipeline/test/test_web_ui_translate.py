# =============================================================
# test_web_ui_translate.py — process_state -> 고객 화면 상태 번역 검증
# -------------------------------------------------------------
# 실행: pytest src/coffee_pipeline/test/test_web_ui_translate.py
# 검증: translate_process_state()가 DEFAULT_STATE 키를 다 채우는지,
#       스텝->스크린 매핑이 process_state.STEPS와 어긋나지 않는지,
#       detail이 top-level 필드를 덮어쓰는지, ERROR 상태가 9번 화면인지.
# fastapi/uvicorn만 있으면 되고 ROS/로봇/DSR SDK는 불필요.
# =============================================================

import pytest

pytest.importorskip("fastapi")

from coffee_pipeline import process_state as ps
from coffee_pipeline import web_ui


def test_default_state_keys_all_present():
    result = web_ui.translate_process_state(
        {"step": "INIT", "status": "RUNNING", "message": "", "label": "초기화",
         "hint": "", "progress": 0.0, "detail": {}})
    assert set(web_ui.DEFAULT_STATE) <= set(result)


def test_every_step_has_a_screen():
    assert set(ps.STEP_KEYS) == set(web_ui.STEP_TO_SCREEN)
    assert all(1 <= n <= 8 for n in web_ui.STEP_TO_SCREEN.values())


def test_error_status_forces_error_screen():
    result = web_ui.translate_process_state(
        {"step": "GRINDING", "status": "ERROR", "message": "grip 실패",
         "label": "분쇄", "hint": "", "progress": 40.0, "detail": {}})
    assert result["screen"] == web_ui.ERROR_SCREEN
    assert result["error"] == "grip 실패"


def test_detail_overrides_defaults():
    result = web_ui.translate_process_state(
        {"step": "HAND_DRIP", "status": "RUNNING", "message": "스파이럴 붓기 중",
         "label": "핸드드립", "hint": "", "progress": 60.0,
         "detail": {"spiral_progress": 42.0, "spiral_stage": "스파이럴 드립"}})
    assert result["spiral_progress"] == 42.0
    assert result["spiral_stage"] == "스파이럴 드립"
    assert result["screen"] == 6


def test_waiting_button_step_flags_waiting_physical_button():
    result = web_ui.translate_process_state(
        {"step": "SELECT_BEAN", "status": "WAITING", "message": "DI13~16 입력 대기",
         "label": "원두 선택 대기", "hint": "DI 13~16", "progress": 0.0, "detail": {}})
    assert result["waiting_physical_button"] is True
    assert result["waiting_external_force"] is False


def test_waiting_tap_step_flags_waiting_external_force():
    result = web_ui.translate_process_state(
        {"step": "WAIT_TAP", "status": "WAITING", "message": "병 두드림 대기",
         "label": "병 두드림 대기", "hint": "외력 감지", "progress": 80.0,
         "detail": {"force_delta_n": 1.2}})
    assert result["waiting_external_force"] is True
    assert result["waiting_physical_button"] is False
    assert result["force_delta_n"] == 1.2


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q", "-p", "no:anyio"]))
